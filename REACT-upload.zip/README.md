# REACT — سرعتت رو ثابت کن

اپلیکیشن اندروید برای آزمون واکنش، حافظه، تمرکز و دقت. فارسی، RTL، تم مشکی/سبز نئونی، کاملاً آفلاین (بدون مجوز INTERNET، بدون ثبت‌نام، بدون تبلیغ).

> **وضعیت صادقانه:** منطق بازی‌ها (پکیج‌های `domain` و `util`) روی JVM کامپایل و با ۷۲ تست واحد تأیید شده است.
> کد Compose/Room/DataStore/Feedback **هنوز هرگز با Android SDK کامپایل نشده** و APK ساخته نشده است. ممکن است در اولین بیلد چند خطای کامپایل داشته باشد.

## پیش‌نیاز
- Android Studio (Ladybug یا جدیدتر) یا JDK 17+ و Android SDK (platform 35، build-tools)
- اتصال اینترنت **فقط برای اولین Sync** (دانلود Gradle و کتابخانه‌ها)؛ خود برنامه آفلاین است.

## اجرا
1. پوشه `REACT` را در Android Studio باز کن و Sync را بزن.
2. یک شبیه‌ساز یا گوشی را وصل کن و Run را بزن.

## ساخت APK (خط فرمان)
```bash
export ANDROID_HOME=/path/to/android-sdk
./gradlew testDebugUnitTest      # تست‌های واحد
./gradlew assembleDebug          # ساخت APK
```
خروجی: `app/build/outputs/apk/debug/app-debug.apk`

## تست منطق بازی‌ها بدون Android SDK
```bash
tools/verify-domain.sh           # نیاز: JDK و Gradle نصب‌شده (مسیر lib با GRADLE_LIB تنظیم می‌شود)
```

## بررسی آفلاین بعد از اولین بیلد
- `app/build/intermediates/merged_manifests/debug/.../AndroidManifest.xml` را باز کن و مطمئن شو `android.permission.INTERNET` در آن **نیست** (ادغام Manifest ممکن است از کتابخانه‌ها مجوز اضافه کند).
- روی دستگاه در حالت هواپیما برنامه را اجرا کن.

## فونت
فایل‌های Vazirmatn (مجوز OFL) را با نام `vazirmatn_regular.ttf` و `vazirmatn_bold.ttf` در `app/src/main/res/font/` بگذار؛ بدون تغییر کد استفاده می‌شوند. در غیر این صورت فونت سیستم به کار می‌رود.

## مستندات
پوشه `PROJECT_HANDOFF/` را ببین (وضعیت، معماری، کارها، پرامپت جلسه بعد).
