package com.react.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class FocusLogicTest {
    @Test fun targetIsAlwaysUniqueAndIndexed() {
        val random = Random(11)
        for (stage in 1..FocusLogic.STAGES) repeat(50) {
            val round = FocusLogic.generate(stage, random)
            assertEquals(FocusLogic.itemCount(stage), round.items.size)
            val matches = round.items.count { it.shape == round.targetShape && it.color == round.targetColor }
            assertEquals("stage=$stage", 1, matches)
            val t = round.items[round.targetIndex]
            assertEquals(round.targetShape, t.shape)
            assertEquals(round.targetColor, t.color)
            assertTrue(round.items.all { it.x in 0f..1f && it.y in 0f..1f })
        }
    }

    @Test fun laterStagesHaveMoreAndMoreSimilarShapes() {
        assertTrue(FocusLogic.itemCount(8) > FocusLogic.itemCount(1))
        assertTrue(FocusLogic.timeLimitMs(8) < FocusLogic.timeLimitMs(1))
        val round = FocusLogic.generate(7, Random(2))
        round.items.forEachIndexed { i, item ->
            if (i != round.targetIndex) {
                val sameShape = item.shape == round.targetShape
                val sameColor = item.color == round.targetColor
                assertTrue("exactly one shared attribute", sameShape != sameColor)
            }
        }
    }

    @Test fun earlyStagesDifferInBothAttributes() {
        val round = FocusLogic.generate(1, Random(4))
        round.items.forEachIndexed { i, item ->
            if (i != round.targetIndex) {
                assertTrue(item.shape != round.targetShape && item.color != round.targetColor)
            }
        }
    }

    @Test fun gridAlwaysFitsAllItems() {
        for (count in 1..60) {
            val (cols, rows) = FocusLogic.gridDimensions(count)
            assertTrue("count=$count", cols * rows >= count && cols >= 1 && rows >= 1)
        }
    }

    @Test fun itemCountAndTimeLimitAreBounded() {
        assertEquals(60, FocusLogic.itemCount(100))
        assertEquals(4_000L, FocusLogic.timeLimitMs(100))
    }

    @Test fun correctAnswerScoresWithSpeedBonus() {
        val s = FocusSession(Random(1))
        val round = s.nextRound()!!
        val answer = s.answer(round.targetIndex, round.timeLimitMs)
        assertEquals(FocusAnswer.Correct(20), answer)
        assertEquals(20, s.score)
        assertEquals(1, s.correct)
        assertEquals(10, FocusLogic.correctPoints(0, 10_000))
    }

    @Test fun wrongAnswerAndTimeoutArePenalizedWithFloorAtZero() {
        val s = FocusSession(Random(1))
        val r1 = s.nextRound()!!
        val wrongIndex = (r1.targetIndex + 1) % r1.items.size
        assertEquals(FocusAnswer.Wrong, s.answer(wrongIndex, 5_000))
        assertEquals(0, s.score)
        s.nextRound()
        s.timeout()
        assertEquals(0, s.score)
        assertEquals(1, s.wrong)
        assertEquals(1, s.timeouts)
    }

    @Test fun sessionFinishesAfterEightStages() {
        val s = FocusSession(Random(8))
        repeat(FocusLogic.STAGES) {
            val r = s.nextRound()!!
            s.answer(r.targetIndex, r.timeLimitMs / 2)
        }
        assertTrue(s.isFinished)
        assertNull(s.nextRound())
        assertEquals(100, s.accuracyPercent)
        assertEquals(FocusAnswer.Ignored, s.answer(0, 100))
        assertTrue(s.performance in 0..100)
    }

    @Test fun nextRoundDoesNotSkipUnansweredStage() {
        val s = FocusSession(Random(3))
        s.nextRound()
        assertNull(s.nextRound())
        assertEquals(1, s.stage)
    }
}
