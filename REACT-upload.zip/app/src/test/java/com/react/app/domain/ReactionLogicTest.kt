package com.react.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class ReactionLogicTest {
    private val ms = 1_000_000L

    @Test fun elapsedMs_convertsNanosAndRounds() {
        assertEquals(250, ReactionLogic.elapsedMs(0, 250 * ms))
        assertEquals(250, ReactionLogic.elapsedMs(1_000, 1_000 + 249_600_000L))
        assertEquals(249, ReactionLogic.elapsedMs(0, 249_400_000L))
    }

    @Test fun randomDelay_isAlwaysBetweenTwoAndFiveSeconds() {
        val random = Random(42)
        repeat(2_000) {
            val d = ReactionLogic.randomDelayMs(random)
            assertTrue("delay=$d", d in 2_000L..5_000L)
        }
    }

    @Test fun touchBeforeGreen_isFalseStartAndRoundIsRepeated() {
        val s = ReactionSession()
        s.beginWaiting()
        assertEquals(ReactionTouch.FalseStart, s.touch(10 * ms))
        assertEquals(ReactionSession.Phase.FALSE_START, s.phase)
        assertEquals(1, s.falseStarts)
        assertEquals(0, s.completedRounds)
        s.beginWaiting()
        assertEquals(ReactionSession.Phase.WAITING, s.phase)
    }

    @Test fun implausiblyFastTouch_isFalseStart() {
        val s = ReactionSession()
        s.beginWaiting()
        s.showGreen(1_000 * ms)
        assertEquals(ReactionTouch.FalseStart, s.touch(1_000 * ms + 50 * ms))
        assertEquals(0, s.completedRounds)
    }

    @Test fun touchOutsideAllowedPhases_isIgnored() {
        val s = ReactionSession()
        assertEquals(ReactionTouch.Ignored, s.touch(0))
        assertEquals(ReactionTouch.Ignored, s.timeout())
        assertEquals(0, s.falseStarts)
    }

    @Test fun fullGame_computesAverageBestWorst() {
        val s = ReactionSession()
        val times = listOf(300, 250, 400, 200, 350)
        var clock = 0L
        times.forEachIndexed { i, t ->
            s.beginWaiting()
            clock += 3_000 * ms
            s.showGreen(clock)
            val result = s.touch(clock + t * ms)
            assertEquals(ReactionTouch.Recorded(t, finished = i == times.lastIndex), result)
        }
        assertEquals(ReactionSession.Phase.FINISHED, s.phase)
        val summary = s.summary()
        assertEquals(300, summary.average)
        assertEquals(200, summary.best)
        assertEquals(400, summary.worst)
        assertTrue(summary.success)
        assertEquals(80, summary.performance)
    }

    @Test fun timeout_recordsTimeoutValue() {
        val s = ReactionSession()
        s.beginWaiting()
        s.showGreen(0)
        assertEquals(ReactionTouch.Recorded(ReactionLogic.TIMEOUT_MS, false), s.timeout())
    }

    @Test fun performance_scale() {
        assertEquals(100, ReactionLogic.performance(200, 0))
        assertEquals(50, ReactionLogic.performance(450, 0))
        assertEquals(0, ReactionLogic.performance(700, 0))
        assertEquals(0, ReactionLogic.performance(1_500, 0))
        assertEquals(40, ReactionLogic.performance(450, 2))
        assertEquals(0, ReactionLogic.performance(0, 0))
    }

    @Test fun summary_notSuccessfulWhenSlowOrIncomplete() {
        assertTrue(!ReactionSummary(listOf(600, 600, 600, 600, 600), 0).success)
        assertTrue(!ReactionSummary(listOf(200, 200), 0).success)
    }
}
