package com.react.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class AimEngineTest {
    private fun engine(seed: Int = 1) = AimEngine(1000f, 1800f, 1f, Random(seed))

    @Test fun nothingSpawnsBeforeFirstSpawnTime() {
        val e = engine()
        e.update(100)
        assertTrue(e.targets.isEmpty())
        e.update(300)
        assertEquals(1, e.targets.size)
    }

    @Test fun tapInsideTargetScoresAndRemovesIt() {
        val e = engine()
        e.update(300)
        val t = e.targets.single()
        val result = e.tap(t.x, t.y)
        assertTrue(result is AimTap.Hit)
        assertTrue((result as AimTap.Hit).points in 10..20)
        assertEquals(1, e.hits)
        assertEquals(result.points, e.score)
        assertTrue(e.targets.isEmpty())
    }

    @Test fun tapOutsideIsPenalizedWithFloorAtZero() {
        val e = engine()
        e.update(300)
        val t = e.targets.single()
        val far = if (t.x < 500f) 990f else 10f
        assertEquals(AimTap.Miss, e.tap(far, if (t.y < 900f) 1790f else 10f))
        assertEquals(0, e.score)
        assertEquals(1, e.missTaps)
    }

    @Test fun missSubtractsFromExistingScore() {
        val e = engine()
        e.update(300)
        val first = e.targets.single()
        e.tap(first.x, first.y)
        val before = e.score
        e.tap(-500f, -500f)
        assertEquals(before - AimEngine.MISS_PENALTY, e.score)
    }

    @Test fun smallerTargetsGivePointsUpToDouble() {
        val e = engine()
        assertEquals(20, e.hitPoints(e.minRadius))
        assertEquals(10, e.hitPoints(e.maxRadius))
        assertTrue(e.hitPoints(e.minRadius) > e.hitPoints(e.maxRadius))
    }

    @Test fun unhitTargetsExpireAndHurtAccuracy() {
        val e = engine()
        e.update(300)
        assertEquals(1, e.targets.size)
        e.update(300 + e.lifetimeMs(300))
        assertEquals(1, e.expired)
        assertEquals(0, e.accuracyPercent)
    }

    @Test fun accuracyCountsHitsAgainstMissesAndExpired() {
        val e = engine()
        e.update(300)
        val t = e.targets.single()
        e.tap(t.x, t.y)
        e.tap(-1000f, -1000f)
        assertEquals(50, e.accuracyPercent)
    }

    @Test fun gameFinishesAtDuration() {
        val e = engine()
        assertTrue(!e.isFinished(29_999))
        assertTrue(e.isFinished(AimEngine.DURATION_MS))
    }

    @Test fun targetsStayInsideArenaAndNeverExceedMaxActive() {
        val e = engine(5)
        var now = 0L
        while (now <= AimEngine.DURATION_MS) {
            e.update(now)
            assertTrue(e.targets.size <= AimEngine.MAX_ACTIVE)
            for (t in e.targets) {
                assertTrue(t.x - t.radius >= -0.01f && t.x + t.radius <= 1000.01f)
                assertTrue(t.y - t.radius >= -0.01f && t.y + t.radius <= 1800.01f)
            }
            now += 16
        }
    }

    @Test fun spawnGetsFasterAndLifetimeShorter() {
        val e = engine()
        assertTrue(e.spawnIntervalMs(25_000) < e.spawnIntervalMs(0))
        assertTrue(e.lifetimeMs(25_000) < e.lifetimeMs(0))
        assertEquals(450L, e.spawnIntervalMs(1_000_000))
    }
}
