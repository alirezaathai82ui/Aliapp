package com.react.app.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ToneSynthTest {
    @Test fun lengthMatchesDuration() {
        val pcm = ToneSynth.render(listOf(ToneSynth.Note(440f, 100), ToneSynth.Note(0f, 50)))
        assertEquals(ToneSynth.sampleCount(100) + ToneSynth.sampleCount(50), pcm.size)
    }

    @Test fun toneIsAudibleButNeverClips() {
        val pcm = ToneSynth.render(listOf(ToneSynth.Note(880f, 200)))
        val peak = pcm.maxOf { abs(it.toInt()) }
        assertTrue("peak=$peak", peak in 2_000..32_000)
    }

    @Test fun silenceIsSilent() {
        val pcm = ToneSynth.render(listOf(ToneSynth.Note(0f, 80)))
        assertTrue(pcm.all { it.toInt() == 0 })
    }

    @Test fun noteEndsNearZeroToAvoidClicks() {
        val pcm = ToneSynth.render(listOf(ToneSynth.Note(660f, 100)))
        assertTrue(abs(pcm.last().toInt()) < 500)
        assertTrue(abs(pcm.first().toInt()) < 500)
    }

    @Test fun everyEffectRendersAndHasDuration() {
        SoundEffect.entries.forEach { effect ->
            val pcm = ToneSynth.render(SoundBank.notes(effect))
            assertTrue("$effect", pcm.size > ToneSynth.SAMPLE_RATE / 20)
            assertTrue("$effect", pcm.any { it.toInt() != 0 })
        }
    }
}
