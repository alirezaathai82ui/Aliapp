package com.react.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProgressionTest {
    private fun record(
        type: GameType,
        performance: Int = 60,
        success: Boolean = true,
        accuracy: Int = -1,
        main: Int = 0,
        best: Int = 0,
        score: Int = 0,
        id: Long = 0,
    ) = ResultRecord(id, type, score, performance, success, accuracy, main, best, 20, 1_000L + id)

    // ---------- سطح‌بندی ----------
    @Test fun levelThresholds() {
        assertEquals(RankLevel.NOVICE, LevelSystem.levelFor(0))
        assertEquals(RankLevel.NOVICE, LevelSystem.levelFor(149))
        assertEquals(RankLevel.BEGINNER, LevelSystem.levelFor(150))
        assertEquals(RankLevel.INTERMEDIATE, LevelSystem.levelFor(450))
        assertEquals(RankLevel.PRO, LevelSystem.levelFor(1000))
        assertEquals(RankLevel.MASTER, LevelSystem.levelFor(2000))
        assertEquals(RankLevel.ELITE, LevelSystem.levelFor(3500))
        assertEquals(RankLevel.ELITE, LevelSystem.levelFor(99_999))
    }

    @Test fun progressAndXpToNext() {
        assertEquals(0f, LevelSystem.progress(0), 0.0001f)
        assertEquals(0.5f, LevelSystem.progress(75), 0.0001f)
        assertEquals(75, LevelSystem.xpToNext(75))
        assertEquals(1f, LevelSystem.progress(5_000), 0.0001f)
        assertEquals(0, LevelSystem.xpToNext(5_000))
    }

    @Test fun xpFormula() {
        assertEquals(40, Scoring.xpFor(100, true))
        assertEquals(10, Scoring.xpFor(0, false))
        assertEquals(30, Scoring.xpFor(50, true))
        assertEquals(19, Scoring.xpFor(49, false))
        assertTrue(Scoring.isSuccess(50))
        assertFalse(Scoring.isSuccess(49))
    }

    // ---------- دستاوردها ----------
    private fun snapshot(vararg r: ResultRecord, xp: Int = 0) = ProgressSnapshot.from(r.toList(), xp)

    @Test fun firstTest() {
        assertFalse(Achievement.FIRST_TEST.isUnlockedBy(snapshot()))
        assertTrue(Achievement.FIRST_TEST.isUnlockedBy(snapshot(record(GameType.AIM))))
    }

    @Test fun tenSuccessfulTests() {
        val nine = List(9) { record(GameType.AIM, id = it.toLong()) }
        val ten = nine + record(GameType.AIM, id = 9)
        assertFalse(Achievement.TEN_SUCCESSES.isUnlockedBy(ProgressSnapshot.from(nine, 0)))
        assertTrue(Achievement.TEN_SUCCESSES.isUnlockedBy(ProgressSnapshot.from(ten, 0)))
        val failures = List(12) { record(GameType.AIM, success = false, id = it.toLong()) }
        assertFalse(Achievement.TEN_SUCCESSES.isUnlockedBy(ProgressSnapshot.from(failures, 0)))
    }

    @Test fun reactionUnder250() {
        assertTrue(Achievement.LIGHTNING.isUnlockedBy(snapshot(record(GameType.REACTION, best = 249))))
        assertFalse(Achievement.LIGHTNING.isUnlockedBy(snapshot(record(GameType.REACTION, best = 250))))
        assertFalse(Achievement.LIGHTNING.isUnlockedBy(snapshot()))
        assertFalse(Achievement.LIGHTNING.isUnlockedBy(snapshot(record(GameType.AIM, best = 100))))
    }

    @Test fun memoryLevelTen() {
        assertFalse(Achievement.MEMORY_TEN.isUnlockedBy(snapshot(record(GameType.MEMORY, main = 9))))
        assertTrue(Achievement.MEMORY_TEN.isUnlockedBy(snapshot(record(GameType.MEMORY, main = 10))))
    }

    @Test fun fiveSuccessStreakUsesNewestResultsFirst() {
        val streak = List(5) { record(GameType.AIM, id = (10 - it).toLong()) } // جدیدترین اول
        assertTrue(Achievement.STREAK_FIVE.isUnlockedBy(ProgressSnapshot.from(streak, 0)))
        val broken = listOf(
            record(GameType.AIM, id = 9), record(GameType.AIM, id = 8, success = false),
            record(GameType.AIM, id = 7), record(GameType.AIM, id = 6), record(GameType.AIM, id = 5),
        )
        assertFalse(Achievement.STREAK_FIVE.isUnlockedBy(ProgressSnapshot.from(broken, 0)))
    }

    @Test fun accuracyAboveNinety() {
        assertFalse(Achievement.ACCURACY_90.isUnlockedBy(snapshot(record(GameType.AIM, accuracy = 90))))
        assertTrue(Achievement.ACCURACY_90.isUnlockedBy(snapshot(record(GameType.AIM, accuracy = 91))))
    }

    @Test fun allRounderAndXp() {
        val all = GameType.entries.map { record(it) }
        assertTrue(Achievement.ALL_ROUNDER.isUnlockedBy(ProgressSnapshot.from(all, 0)))
        assertFalse(Achievement.ALL_ROUNDER.isUnlockedBy(ProgressSnapshot.from(all.drop(1), 0)))
        assertTrue(Achievement.XP_1000.isUnlockedBy(snapshot(xp = 1000)))
        assertFalse(Achievement.XP_1000.isUnlockedBy(snapshot(xp = 999)))
    }

    @Test fun alreadyUnlockedAreNotReported() {
        val snap = snapshot(record(GameType.AIM))
        assertEquals(listOf(Achievement.FIRST_TEST), AchievementEngine.newlyUnlocked(snap, emptySet()))
        assertTrue(AchievementEngine.newlyUnlocked(snap, setOf("FIRST_TEST")).isEmpty())
    }

    // ---------- آمار ----------
    @Test fun summaryValues() {
        val results = listOf(
            record(GameType.REACTION, main = 300, best = 240, id = 3, performance = 80),
            record(GameType.REACTION, main = 400, best = 310, id = 2, performance = 60),
            record(GameType.MEMORY, main = 7, id = 1, accuracy = 80, performance = 70),
            record(GameType.FOCUS, score = 90, id = 0, accuracy = 60, performance = 90, success = false),
        )
        val records = listOf(
            RecordSnapshot(GameType.REACTION, 300, 240, 80, 0),
            RecordSnapshot(GameType.MEMORY, 7, 0, 70, 80),
            RecordSnapshot(GameType.FOCUS, 90, 0, 90, 60),
        )
        val s = StatsCalculator.summarize(results, records)
        assertEquals(240, s.bestReactionMs)
        assertEquals(350, s.averageReactionMs)
        assertEquals(7, s.bestMemoryRounds)
        assertEquals(90, s.bestFocusScore)
        assertEquals(70, s.accuracyPercent)
        assertEquals(4, s.totalTests)
        assertEquals(3, s.successfulTests)
    }

    @Test fun emptySummaryHasNoInventedNumbers() {
        val s = StatsCalculator.summarize(emptyList())
        assertEquals(null, s.bestReactionMs)
        assertEquals(null, s.averageReactionMs)
        assertEquals(null, s.accuracyPercent)
        assertEquals(0, s.overallPerformance)
    }

    @Test fun overallPerformanceUsesFiveRecentPerGameThenAveragesGames() {
        val reaction = (0 until 7).map { record(GameType.REACTION, performance = if (it < 5) 80 else 0, id = (100 - it).toLong()) }
        val aim = listOf(record(GameType.AIM, performance = 40, id = 1))
        assertEquals(60, StatsCalculator.overallPerformance(reaction + aim))
    }

    @Test fun trendIsChronologicalAndFilterable() {
        val results = listOf(
            record(GameType.AIM, performance = 30, id = 3),
            record(GameType.MEMORY, performance = 20, id = 2),
            record(GameType.AIM, performance = 10, id = 1),
        )
        assertEquals(listOf(10, 20, 30), StatsCalculator.trend(results))
        assertEquals(listOf(10, 30), StatsCalculator.trend(results, GameType.AIM))
        assertEquals(listOf(30), StatsCalculator.trend(results, limit = 1))
    }
}
