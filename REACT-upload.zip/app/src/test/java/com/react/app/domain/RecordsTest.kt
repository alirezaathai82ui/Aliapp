package com.react.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class RecordsTest {
    private fun reaction(avg: Int, best: Int, score: Int = 60) =
        NewResult(GameType.REACTION, score, score, true, -1, avg, best)

    @Test fun reactionRecordKeepsLowestPositiveTimes() {
        val first = RecordRules.merge(null, reaction(320, 250))
        assertEquals(320, first.bestMain)
        assertEquals(250, first.bestSecondary)
        val second = RecordRules.merge(first, reaction(400, 200))
        assertEquals(320, second.bestMain)
        assertEquals(200, second.bestSecondary)
        val third = RecordRules.merge(second, reaction(0, 0))
        assertEquals(second, third)
    }

    @Test fun otherGamesKeepHighestValues() {
        val a = RecordRules.merge(null, NewResult(GameType.MEMORY, 70, 70, true, 80, 7, 0))
        val b = RecordRules.merge(a, NewResult(GameType.MEMORY, 40, 40, false, 95, 4, 0))
        assertEquals(7, b.bestMain)
        assertEquals(70, b.bestScore)
        assertEquals(95, b.bestAccuracy)
        assertEquals(0, b.bestSecondary)
    }

    @Test fun unavailableAccuracyDoesNotCountAsRecord() {
        val r = RecordRules.merge(null, reaction(300, 250))
        assertEquals(0, r.bestAccuracy)
    }

    @Test fun profileNameSanitizing() {
        assertEquals("علی رضا", Profile.sanitizeName("  علی    رضا  "))
        assertEquals(Profile.DEFAULT_NAME, Profile.sanitizeName("   "))
        assertEquals(16, Profile.sanitizeName("ا".repeat(40)).length)
    }

    @Test fun snapshotFromPersistentStateIgnoresHistory() {
        val profile = Profile(xp = 1200, totalTests = 12, successfulTests = 11, successStreak = 6)
        val records = listOf(
            RecordSnapshot(GameType.REACTION, 300, 210, 80, 0),
            RecordSnapshot(GameType.MEMORY, 10, 0, 100, 91),
        )
        val snap = ProgressSnapshot.from(profile, records)
        assertTrue(Achievement.TEN_SUCCESSES.isUnlockedBy(snap))
        assertTrue(Achievement.LIGHTNING.isUnlockedBy(snap))
        assertTrue(Achievement.MEMORY_TEN.isUnlockedBy(snap))
        assertTrue(Achievement.STREAK_FIVE.isUnlockedBy(snap))
        assertTrue(Achievement.ACCURACY_90.isUnlockedBy(snap))
        assertTrue(Achievement.XP_1000.isUnlockedBy(snap))
        assertFalse(Achievement.ALL_ROUNDER.isUnlockedBy(snap))
    }

    @Test fun resultFactoryBuildsConsistentResults() {
        val reactionSummary = ReactionSummary(listOf(200, 220, 240, 260, 280), 0)
        val r = ResultFactory.reaction(reactionSummary)
        assertEquals(240, r.mainValue)
        assertEquals(200, r.bestValue)
        assertEquals(-1, r.accuracy)
        assertTrue(r.success)

        val focus = FocusSession(Random(1))
        repeat(FocusLogic.STAGES) {
            val round = focus.nextRound()!!
            focus.answer(round.targetIndex, round.timeLimitMs - 1_000)
        }
        val f = ResultFactory.focus(focus)
        assertEquals(100, f.accuracy)
        assertEquals(1_000, f.bestValue)
        assertEquals(focus.score, f.mainValue)

        val stroop = StroopSession(Random(1))
        repeat(StroopLogic.QUESTIONS) {
            val q = stroop.next()!!
            stroop.answer(q.ink, q.timeLimitMs - 500)
        }
        assertEquals(500, ResultFactory.stroop(stroop).bestValue)
    }

    @Test fun outcomeDetectsLevelUp() {
        val up = RecordOutcome(30, 160, RankLevel.NOVICE, RankLevel.BEGINNER, emptyList(), false)
        val same = RecordOutcome(30, 100, RankLevel.NOVICE, RankLevel.NOVICE, emptyList(), false)
        assertTrue(up.leveledUp)
        assertFalse(same.leveledUp)
    }
}
