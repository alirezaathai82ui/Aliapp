package com.react.app.util

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class PersianFormatTest {
    private val utc = ZoneId.of("UTC")

    @Test fun digitsAreConverted() {
        assertEquals("۰۱۲۳۴۵۶۷۸۹", PersianFormat.digits("0123456789"))
        assertEquals("۲۵۰ ms", PersianFormat.digits("250 ms"))
        assertEquals("۱۲", PersianFormat.digits(12))
    }

    @Test fun nowruzDates() {
        assertEquals(Triple(1403, 1, 1), PersianFormat.gregorianToJalali(2024, 3, 20))
        assertEquals(Triple(1404, 1, 1), PersianFormat.gregorianToJalali(2025, 3, 21))
        assertEquals(Triple(1405, 1, 1), PersianFormat.gregorianToJalali(2026, 3, 21))
    }

    @Test fun midYearAndYearEnd() {
        assertEquals(Triple(1405, 8, 29), PersianFormat.gregorianToJalali(2026, 11, 20))
        assertEquals(Triple(1404, 12, 29), PersianFormat.gregorianToJalali(2026, 3, 20))
        assertEquals(Triple(1404, 10, 11), PersianFormat.gregorianToJalali(2026, 1, 1))
    }

    @Test fun formattedDateAndTime() {
        val millis = ZonedDateTime.of(2026, 11, 20, 12, 5, 0, 0, utc).toInstant().toEpochMilli()
        assertEquals("۲۹ آبان ۱۴۰۵", PersianFormat.date(millis, utc))
        assertEquals("۱۲:۰۵", PersianFormat.time(millis, utc))
        assertEquals("۲۹ آبان ۱۴۰۵ - ۱۲:۰۵", PersianFormat.dateTime(millis, utc))
    }
}
