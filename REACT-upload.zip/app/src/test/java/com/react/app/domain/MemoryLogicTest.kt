package com.react.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class MemoryLogicTest {
    @Test fun gridGrowsWithRound() {
        assertEquals(3, MemoryLogic.gridSizeFor(1))
        assertEquals(3, MemoryLogic.gridSizeFor(5))
        assertEquals(4, MemoryLogic.gridSizeFor(6))
        assertEquals(4, MemoryLogic.gridSizeFor(12))
        assertEquals(5, MemoryLogic.gridSizeFor(13))
    }

    @Test fun eachRoundAddsExactlyOneMoveAndKeepsPrefix() {
        val s = MemorySession(Random(7))
        var previous = emptyList<Cell>()
        repeat(8) { i ->
            val seq = s.startNextRound()
            assertEquals(i + 1, seq.size)
            assertEquals(previous, seq.take(previous.size))
            seq.forEach { c ->
                assertTrue(c.row in 0 until MemoryLogic.gridSizeFor(s.round))
                assertTrue(c.col in 0 until MemoryLogic.gridSizeFor(s.round))
            }
            seq.forEach { s.tap(it) }
            previous = seq
        }
        assertEquals(8, s.completedRounds)
    }

    @Test fun correctRepeatCompletesRound() {
        val s = MemorySession(Random(1))
        val seq = s.startNextRound()
        assertEquals(MemoryTap.RoundComplete(1), s.tap(seq[0]))
        assertEquals(1, s.completedRounds)
        assertTrue(!s.isOver)
    }

    @Test fun wrongTapEndsGame() {
        val s = MemorySession(Random(3))
        s.startNextRound().forEach { s.tap(it) }
        val seq = s.startNextRound()
        val wrong = Cell((seq[0].row + 1) % 3, seq[0].col)
        assertEquals(MemoryTap.Wrong, s.tap(wrong))
        assertTrue(s.isOver)
        assertEquals(1, s.completedRounds)
        assertEquals(MemoryTap.Ignored, s.tap(seq[0]))
    }

    @Test fun intermediateCorrectTapIsCorrectNotComplete() {
        val s = MemorySession(Random(5))
        s.startNextRound().forEach { s.tap(it) }
        val seq = s.startNextRound()
        assertEquals(MemoryTap.Correct, s.tap(seq[0]))
        assertEquals(MemoryTap.RoundComplete(2), s.tap(seq[1]))
    }

    @Test fun accuracyAndScore() {
        val s = MemorySession(Random(9))
        s.startNextRound().forEach { s.tap(it) }
        val seq = s.startNextRound()
        s.tap(seq[0])
        s.tap(Cell(2, 2).takeIf { it != seq[1] } ?: Cell(0, 0))
        assertEquals(3, s.totalTaps)
        assertEquals(2, s.correctTaps)
        assertEquals(66, s.accuracyPercent)
        assertEquals(10, MemoryLogic.score(1))
        assertEquals(100, MemoryLogic.performance(15))
    }

    @Test fun flashSpeedsUpButHasFloor() {
        assertTrue(MemoryLogic.flashDurationMs(1) > MemoryLogic.flashDurationMs(10))
        assertEquals(260L, MemoryLogic.flashDurationMs(100))
    }
}
