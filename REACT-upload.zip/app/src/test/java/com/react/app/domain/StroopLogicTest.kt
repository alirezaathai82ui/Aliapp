package com.react.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class StroopLogicTest {
    @Test fun wordNeverMatchesInkAndInkIsAmongOptions() {
        val random = Random(21)
        for (i in 0 until StroopLogic.QUESTIONS) repeat(100) {
            val q = StroopLogic.generate(i, random)
            assertTrue(q.word != q.ink)
            assertTrue(q.ink in q.options)
            assertEquals(StroopLogic.paletteSize(i), q.options.size)
            assertEquals(q.options.size, q.options.toSet().size)
        }
    }

    @Test fun difficultyRamps() {
        assertEquals(4, StroopLogic.paletteSize(0))
        assertEquals(5, StroopLogic.paletteSize(7))
        assertEquals(6, StroopLogic.paletteSize(14))
        assertTrue(StroopLogic.timeLimitMs(19) < StroopLogic.timeLimitMs(0))
        assertEquals(1_200L, StroopLogic.timeLimitMs(1_000))
    }

    @Test fun correctAnswerIsTheInkColorNotTheWord() {
        val s = StroopSession(Random(2))
        val q = s.next()!!
        assertEquals(StroopAnswer.Wrong, run {
            val s2 = StroopSession(Random(2))
            val q2 = s2.next()!!
            s2.answer(q2.word, 1_000)
        })
        val ok = s.answer(q.ink, q.timeLimitMs)
        assertEquals(StroopAnswer.Correct(15), ok)
        assertEquals(1, s.correct)
    }

    @Test fun wrongAndTimeoutCountAsWrongWithScoreFloor() {
        val s = StroopSession(Random(6))
        s.next()
        s.timeout()
        assertEquals(0, s.score)
        assertEquals(1, s.wrong)
        val q = s.next()!!
        s.answer(q.ink, 0)
        assertEquals(10, s.score)
        val q3 = s.next()!!
        s.answer(q3.word, 100)
        assertEquals(5, s.score)
        assertEquals(2, s.wrong)
    }

    @Test fun sessionEndsAfterTwentyQuestions() {
        val s = StroopSession(Random(10))
        repeat(StroopLogic.QUESTIONS) {
            val q = s.next()!!
            s.answer(q.ink, q.timeLimitMs / 2)
        }
        assertTrue(s.isFinished)
        assertNull(s.next())
        assertEquals(100, s.accuracyPercent)
        assertEquals(100, s.performance.coerceAtMost(100))
        assertEquals(StroopAnswer.Ignored, s.answer(GameColor.RED, 100))
    }

    @Test fun questionIsNotSkippedWhileOneIsPending() {
        val s = StroopSession(Random(1))
        s.next()
        assertNull(s.next())
        assertEquals(1, s.asked)
    }
}
