package com.react.app.util

import java.time.Instant
import java.time.ZoneId

/** قالب‌بندی اعداد و تاریخ فارسی (شمسی) بدون وابستگی به اندروید. */
object PersianFormat {
    private val monthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
    )

    fun digits(input: String): String = buildString(input.length) {
        for (c in input) append(if (c in '0'..'9') '۰' + (c - '0') else c)
    }

    fun digits(number: Int): String = digits(number.toString())

    fun digits(number: Long): String = digits(number.toString())

    /** تبدیل تاریخ میلادی به شمسی؛ خروجی (سال، ماه، روز). */
    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val cumulative = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 +
            gd + cumulative[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return Triple(jy, jm, jd)
    }

    fun monthName(month: Int): String = monthNames[month - 1]

    /** مثلاً «۲۹ آبان ۱۴۰۵». */
    fun date(epochMillis: Long, zone: ZoneId = ZoneId.systemDefault()): String {
        val d = Instant.ofEpochMilli(epochMillis).atZone(zone)
        val (jy, jm, jd) = gregorianToJalali(d.year, d.monthValue, d.dayOfMonth)
        return digits("$jd ${monthName(jm)} $jy")
    }

    /** مثلاً «۱۲:۰۵». */
    fun time(epochMillis: Long, zone: ZoneId = ZoneId.systemDefault()): String {
        val d = Instant.ofEpochMilli(epochMillis).atZone(zone)
        return digits("%02d:%02d".format(d.hour, d.minute))
    }

    fun dateTime(epochMillis: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        "${date(epochMillis, zone)} - ${time(epochMillis, zone)}"
}
