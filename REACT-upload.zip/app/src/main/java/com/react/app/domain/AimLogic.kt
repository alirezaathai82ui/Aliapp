package com.react.app.domain

import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

class AimTarget(
    val id: Int,
    var x: Float,
    var y: Float,
    val radius: Float,
    var vx: Float,
    var vy: Float,
    val bornMs: Long,
    val lifetimeMs: Long,
)

sealed interface AimTap {
    data class Hit(val points: Int, val x: Float, val y: Float) : AimTap
    data object Miss : AimTap
}

/**
 * موتور خالص بازی تست دقت. تمام واحدها پیکسل و میلی‌ثانیه‌اند و زمان از بیرون داده می‌شود.
 * [density] برای مقیاس‌دهی اندازه‌ها و سرعت‌ها روی صفحه‌های مختلف است.
 */
class AimEngine(
    private val width: Float,
    private val height: Float,
    private val density: Float = 1f,
    private val random: Random = Random.Default,
) {
    companion object {
        const val DURATION_MS = 30_000L
        const val HIT_BASE = 10
        const val MISS_PENALTY = 3
        const val MAX_ACTIVE = 4
    }

    val minRadius: Float = 18f * density
    val maxRadius: Float = 44f * density
    private val touchSlop: Float = 4f * density

    private val active = mutableListOf<AimTarget>()
    val targets: List<AimTarget> get() = active

    var score: Int = 0
        private set
    var hits: Int = 0
        private set
    var missTaps: Int = 0
        private set
    var expired: Int = 0
        private set

    private var lastMs = 0L
    private var nextSpawnMs = 300L
    private var nextId = 1

    val accuracyPercent: Int
        get() {
            val total = hits + missTaps + expired
            return if (total == 0) 0 else hits * 100 / total
        }

    val performance: Int get() = Scoring.normalize(score, Scoring.AIM_REFERENCE_SCORE)

    fun isFinished(nowMs: Long): Boolean = nowMs >= DURATION_MS

    fun spawnIntervalMs(nowMs: Long): Long = (1000L - nowMs / 1000L * 15L).coerceAtLeast(450L)

    fun lifetimeMs(nowMs: Long): Long = (2600L - nowMs / 1000L * 25L).coerceAtLeast(1400L)

    /** امتیاز برخورد: هدف کوچک‌تر امتیاز بیشتر (۱۰ تا ۲۰). */
    fun hitPoints(radius: Float): Int {
        val span = (maxRadius - minRadius).coerceAtLeast(1f)
        val smallness = ((maxRadius - radius) / span).coerceIn(0f, 1f)
        return (HIT_BASE * (1f + smallness)).roundToInt()
    }

    fun update(nowMs: Long) {
        val now = nowMs.coerceAtMost(DURATION_MS)
        val dt = (now - lastMs).coerceAtLeast(0L) / 1000f
        lastMs = now

        for (t in active) {
            t.x += t.vx * dt
            t.y += t.vy * dt
            if (t.x - t.radius < 0f) { t.x = t.radius; t.vx = kotlin.math.abs(t.vx) }
            if (t.x + t.radius > width) { t.x = width - t.radius; t.vx = -kotlin.math.abs(t.vx) }
            if (t.y - t.radius < 0f) { t.y = t.radius; t.vy = kotlin.math.abs(t.vy) }
            if (t.y + t.radius > height) { t.y = height - t.radius; t.vy = -kotlin.math.abs(t.vy) }
        }

        val iterator = active.iterator()
        while (iterator.hasNext()) {
            val t = iterator.next()
            if (now - t.bornMs >= t.lifetimeMs) {
                iterator.remove()
                expired++
            }
        }

        if (now < DURATION_MS && now >= nextSpawnMs) {
            if (active.size < MAX_ACTIVE) spawn(now)
            nextSpawnMs = now + spawnIntervalMs(now)
        }
    }

    fun tap(x: Float, y: Float): AimTap {
        val target = active.lastOrNull { hypot(it.x - x, it.y - y) <= it.radius + touchSlop }
        return if (target != null) {
            active.remove(target)
            val points = hitPoints(target.radius)
            hits++
            score += points
            AimTap.Hit(points, target.x, target.y)
        } else {
            missTaps++
            score = (score - MISS_PENALTY).coerceAtLeast(0)
            AimTap.Miss
        }
    }

    private fun spawn(nowMs: Long) {
        val radius = minRadius + random.nextFloat() * (maxRadius - minRadius)
        val x = radius + random.nextFloat() * (width - 2 * radius).coerceAtLeast(0f)
        val y = radius + random.nextFloat() * (height - 2 * radius).coerceAtLeast(0f)
        val baseSpeed = (30f + (nowMs / 1000f) * 3f).coerceAtMost(90f) * density
        val speed = baseSpeed * random.nextFloat()
        val angle = random.nextFloat() * (2f * Math.PI.toFloat())
        active += AimTarget(
            id = nextId++,
            x = x,
            y = y,
            radius = radius,
            vx = cos(angle) * speed,
            vy = sin(angle) * speed,
            bornMs = nowMs,
            lifetimeMs = lifetimeMs(nowMs),
        )
    }
}
