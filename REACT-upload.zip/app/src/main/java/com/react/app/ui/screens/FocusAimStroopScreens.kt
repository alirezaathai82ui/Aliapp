package com.react.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.react.app.domain.AimEngine
import com.react.app.domain.FocusLogic
import com.react.app.domain.GameColor
import com.react.app.domain.GameType
import com.react.app.domain.StroopLogic
import com.react.app.ui.components.OnStopEffect
import com.react.app.ui.components.ScreenScaffold
import com.react.app.ui.components.drawGameShape
import com.react.app.ui.fa
import com.react.app.ui.percentText
import com.react.app.ui.theme.ReactColors
import com.react.app.ui.theme.accent
import com.react.app.ui.theme.toColor
import com.react.app.ui.viewmodel.AimPhase
import com.react.app.ui.viewmodel.AimViewModel
import com.react.app.ui.viewmodel.FocusPhase
import com.react.app.ui.viewmodel.FocusViewModel
import com.react.app.ui.viewmodel.StroopPhase
import com.react.app.ui.viewmodel.StroopViewModel
import kotlin.math.hypot
import kotlin.math.min

// ───────────────────────────── تمرکز ─────────────────────────────

@Composable
fun FocusScreen(vm: FocusViewModel, onBack: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val outcome by vm.outcome.collectAsState()
    val accent = GameType.FOCUS.accent()
    OnStopEffect { vm.onLeave() }

    val playing = ui.phase == FocusPhase.PLAYING || ui.phase == FocusPhase.FEEDBACK
    ScreenScaffold(GameType.FOCUS.title, onBack, scroll = !playing) {
        when (ui.phase) {
            FocusPhase.INTRO -> GameIntro(
                GameType.FOCUS,
                listOf(
                    "یک شکل هدف بالای صفحه نشان داده می‌شود (شکل + رنگ).",
                    "همان شکل را میان شکل‌های مشابه پیدا کن و لمس کن.",
                    "هر مرحله زمان محدود دارد و در ${FocusLogic.STAGES.fa()} مرحله شکل‌ها بیشتر و شبیه‌تر می‌شوند.",
                    "پاسخ اشتباه یا تمام شدن زمان، امتیاز منفی دارد.",
                ),
                onStart = vm::start,
            )

            FocusPhase.FINISHED -> ResultPanel(
                type = GameType.FOCUS,
                performance = ui.performance,
                success = com.react.app.domain.Scoring.isSuccess(ui.performance),
                lines = listOf(
                    "امتیاز" to ui.score.fa(),
                    "دقت" to percentText(ui.accuracy),
                    "پاسخ درست" to "${ui.correct.fa()} از ${FocusLogic.STAGES.fa()}",
                    "میانگین زمان پاسخ درست" to if (ui.correct > 0) "${(ui.averageTimeMs / 1000.0).let { "%.1f".format(it) }.fa()} ثانیه" else "—",
                ),
                outcome = outcome,
                onRetry = vm::start,
                onHome = onBack,
            )

            else -> {
                val round = ui.round ?: return@ScreenScaffold
                GameHud(
                    left = "مرحله ${round.stage.fa()} از ${FocusLogic.STAGES.fa()}",
                    center = "هدف",
                    right = "امتیاز ${ui.score.fa()}",
                    accent = accent,
                    progress = (ui.remainingMs.toFloat() / round.timeLimitMs).coerceIn(0f, 1f),
                )
                Row(
                    Modifier.fillMaxWidth().height(56.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Canvas(Modifier.size(44.dp)) {
                        drawGameShape(round.targetShape, Offset(size.width / 2, size.height / 2), size.minDimension * 0.45f, round.targetColor.toColor())
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "${round.targetShape.fa} ${round.targetColor.fa}",
                        color = ReactColors.TextPrimary,
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
                FocusArena(ui, round, onPick = vm::answer, modifier = Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

@Composable
private fun FocusArena(
    ui: com.react.app.ui.viewmodel.FocusUi,
    round: com.react.app.domain.FocusRound,
    onPick: (Int) -> Unit,
    modifier: Modifier,
) {
    val (cols, rows) = FocusLogic.gridDimensions(round.items.size)
    BoxWithConstraints(modifier.clip(RoundedCornerShape(20.dp)).background(ReactColors.Card)) {
        val w = with(LocalDensity.current) { maxWidth.toPx() }
        val h = with(LocalDensity.current) { maxHeight.toPx() }
        val radius = min(w / cols, h / rows) * 0.34f
        Canvas(
            Modifier.fillMaxSize().pointerInput(round) {
                detectTapGestures { tap ->
                    val index = round.items.indices.minByOrNull {
                        hypot(round.items[it].x * w - tap.x, round.items[it].y * h - tap.y)
                    } ?: return@detectTapGestures
                    val item = round.items[index]
                    if (hypot(item.x * w - tap.x, item.y * h - tap.y) <= radius * 1.35f) onPick(index)
                }
            },
        ) {
            round.items.forEachIndexed { i, item ->
                drawGameShape(item.shape, Offset(item.x * w, item.y * h), radius, item.color.toColor())
            }
            if (ui.phase == FocusPhase.FEEDBACK) {
                val t = round.items[round.targetIndex]
                drawCircle(ReactColors.Green, radius * 1.35f, Offset(t.x * w, t.y * h), style = Stroke(4.dp.toPx()))
                ui.chosen?.takeIf { it != round.targetIndex }?.let {
                    val c = round.items[it]
                    drawCircle(ReactColors.Warning, radius * 1.35f, Offset(c.x * w, c.y * h), style = Stroke(4.dp.toPx()))
                }
            }
        }
    }
}

// ───────────────────────────── دقت ─────────────────────────────

private val AimHudHeight = 72.dp

@Composable
fun AimScreen(vm: AimViewModel, onBack: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val outcome by vm.outcome.collectAsState()
    val accent = GameType.AIM.accent()
    val density = LocalDensity.current
    OnStopEffect { vm.onLeave() }

    // اسکرول فقط داخل معرفی/نتیجه است؛ محیط بازی باید اندازه ثابت و دقیق داشته باشد.
    ScreenScaffold(GameType.AIM.title, onBack, scroll = false) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val widthPx = with(density) { maxWidth.toPx() }
            val arenaHeightPx = with(density) { (maxHeight - AimHudHeight).toPx() }
            when (ui.phase) {
                AimPhase.INTRO -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    GameIntro(
                        GameType.AIM,
                        listOf(
                            "اهداف با اندازه‌های مختلف در نقاط تصادفی ظاهر می‌شوند و حرکت می‌کنند.",
                            "هر هدف را قبل از ناپدید شدن لمس کن؛ هدف کوچک‌تر امتیاز بیشتری دارد.",
                            "لمس جای خالی از امتیازت کم می‌کند.",
                            "آزمون ${(AimEngine.DURATION_MS / 1000).toInt().fa()} ثانیه است و درصد دقت محاسبه می‌شود.",
                        ),
                        onStart = { vm.start(widthPx, arenaHeightPx, density.density) },
                    )
                }

                AimPhase.FINISHED -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    ResultPanel(
                        type = GameType.AIM,
                        performance = ui.performance,
                        success = com.react.app.domain.Scoring.isSuccess(ui.performance),
                        lines = listOf(
                            "امتیاز" to ui.score.fa(),
                            "درصد دقت" to percentText(ui.accuracy),
                            "برخورد موفق" to ui.hits.fa(),
                            "لمس اشتباه" to ui.missTaps.fa(),
                            "هدف از دست‌رفته" to ui.expired.fa(),
                        ),
                        outcome = outcome,
                        onRetry = { vm.start(widthPx, arenaHeightPx, density.density) },
                        onHome = onBack,
                    )
                }

                AimPhase.PLAYING -> Column(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxWidth().height(AimHudHeight)) {
                        GameHud(
                            left = "امتیاز ${ui.score.fa()}",
                            center = "${(ui.remainingMs / 1000 + 1).coerceAtMost(AimEngine.DURATION_MS / 1000).fa()} ثانیه",
                            right = "دقت ${percentText(ui.accuracy)}",
                            accent = accent,
                            progress = ui.remainingMs.toFloat() / AimEngine.DURATION_MS,
                        )
                    }
                    Canvas(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(ReactColors.Card)
                            .pointerInput(Unit) { detectTapGestures(onPress = { vm.tap(it.x, it.y) }) },
                    ) {
                        ui.targets.forEach { t ->
                            val c = Offset(t.x, t.y)
                            drawCircle(accent.copy(alpha = 0.18f), t.radius * 1.25f, c)
                            drawCircle(accent, t.radius, c)
                            drawCircle(ReactColors.Background, t.radius * 0.62f, c)
                            drawCircle(accent, t.radius * 0.28f, c)
                            // حلقه بیرونی با گذر زمان کوتاه می‌شود و باقی‌مانده عمر هدف را نشان می‌دهد
                            drawArc(
                                Color.White.copy(alpha = 0.85f), -90f, 360f * (1f - t.ageFraction), false,
                                topLeft = Offset(c.x - t.radius * 1.12f, c.y - t.radius * 1.12f),
                                size = Size(t.radius * 2.24f, t.radius * 2.24f),
                                style = Stroke(2.dp.toPx(), cap = StrokeCap.Round),
                            )
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────────── چالش رنگ‌ها ─────────────────────────────

@Composable
fun StroopScreen(vm: StroopViewModel, onBack: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val outcome by vm.outcome.collectAsState()
    val accent = GameType.STROOP.accent()
    OnStopEffect { vm.onLeave() }

    val playing = ui.phase == StroopPhase.PLAYING || ui.phase == StroopPhase.FEEDBACK
    ScreenScaffold(GameType.STROOP.title, onBack, scroll = !playing) {
        when (ui.phase) {
            StroopPhase.INTRO -> GameIntro(
                GameType.STROOP,
                listOf(
                    "یک کلمه‌ی رنگ نمایش داده می‌شود، مثلاً «قرمز» با رنگ سبز.",
                    "رنگ واقعی نوشته را انتخاب کن، نه معنی کلمه را.",
                    "هر سؤال زمان محدود دارد و با پیشرفت سریع‌تر می‌شود و رنگ‌های بیشتری ظاهر می‌شوند.",
                    "پاسخ اشتباه یا تمام شدن زمان، امتیاز منفی دارد. (${StroopLogic.QUESTIONS.fa()} سؤال)",
                ),
                onStart = vm::start,
            )

            StroopPhase.FINISHED -> ResultPanel(
                type = GameType.STROOP,
                performance = ui.performance,
                success = com.react.app.domain.Scoring.isSuccess(ui.performance),
                lines = listOf(
                    "امتیاز نهایی" to ui.score.fa(),
                    "پاسخ درست" to ui.correct.fa(),
                    "پاسخ اشتباه" to ui.wrong.fa(),
                    "دقت" to percentText(ui.accuracy),
                ),
                outcome = outcome,
                onRetry = vm::start,
                onHome = onBack,
            )

            else -> {
                val q = ui.question ?: return@ScreenScaffold
                GameHud(
                    left = "سؤال ${ui.asked.fa()} از ${StroopLogic.QUESTIONS.fa()}",
                    center = "درست ${ui.correct.fa()} · غلط ${ui.wrong.fa()}",
                    right = "امتیاز ${ui.score.fa()}",
                    accent = accent,
                    progress = (ui.remainingMs.toFloat() / q.timeLimitMs).coerceIn(0f, 1f),
                )
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("رنگ نوشته چیست؟", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(16.dp))
                        Text(q.word.fa, color = q.ink.toColor(), fontSize = 64.sp, fontWeight = FontWeight.Bold)
                    }
                }
                val rows = q.options.chunked(2)
                rows.forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { option ->
                            val chosenWrong = ui.phase == StroopPhase.FEEDBACK && ui.chosen == option && option != q.ink
                            val isAnswer = ui.phase == StroopPhase.FEEDBACK && option == q.ink
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(64.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(option.toColor())
                                    .border(
                                        if (chosenWrong || isAnswer) 4.dp else 0.dp,
                                        if (chosenWrong) Color.White else ReactColors.Background,
                                        RoundedCornerShape(16.dp),
                                    )
                                    .clickable(enabled = ui.phase == StroopPhase.PLAYING) { vm.answer(option) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(option.fa, color = ReactColors.Background, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

