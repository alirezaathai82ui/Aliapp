package com.react.app.domain

import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.random.Random

/** مختصات x و y نرمال‌شده (۰..۱) هستند و در لایه UI به اندازه محیط بازی تبدیل می‌شوند. */
data class FocusItem(val shape: ShapeKind, val color: GameColor, val x: Float, val y: Float)

data class FocusRound(
    val stage: Int,
    val targetShape: ShapeKind,
    val targetColor: GameColor,
    val items: List<FocusItem>,
    val targetIndex: Int,
    val timeLimitMs: Long,
)

object FocusLogic {
    const val STAGES = 8
    const val CORRECT_BASE = 10
    const val WRONG_PENALTY = 5

    fun itemCount(stage: Int): Int = (12 + 6 * (stage - 1)).coerceAtMost(60)

    fun timeLimitMs(stage: Int): Long = (10_000L - (stage - 1) * 600L).coerceAtLeast(4_000L)

    /** امتیاز پاسخ درست: ۱۰ پایه + حداکثر ۱۰ پاداش سرعت. */
    fun correctPoints(remainingMs: Long, limitMs: Long): Int {
        val fraction = (remainingMs.toDouble() / limitMs).coerceIn(0.0, 1.0)
        return CORRECT_BASE + (10.0 * fraction).roundToInt()
    }

    fun generate(stage: Int, random: Random): FocusRound {
        val shapes = ShapeKind.entries
        val colors = GameColor.entries
        val targetShape = shapes.random(random)
        val targetColor = colors.random(random)
        val count = itemCount(stage)
        val distractors = List(count - 1) { distractor(stage, targetShape, targetColor, random) }
        val positions = layout(count, random)
        val targetIndex = random.nextInt(count)
        val items = List(count) { i ->
            val (shape, color) = when {
                i == targetIndex -> targetShape to targetColor
                i < targetIndex -> distractors[i]
                else -> distractors[i - 1]
            }
            FocusItem(shape, color, positions[i].first, positions[i].second)
        }
        return FocusRound(stage, targetShape, targetColor, items, targetIndex, timeLimitMs(stage))
    }

    /**
     * شکل مزاحم هرگز همزمان هم‌شکل و هم‌رنگ هدف نیست، پس هدف همیشه یکتاست.
     * مرحله‌های اول در هر دو ویژگی متفاوتند؛ با پیشرفت، فقط در یک ویژگی تفاوت دارند (شباهت بیشتر).
     */
    private fun distractor(
        stage: Int,
        targetShape: ShapeKind,
        targetColor: GameColor,
        random: Random,
    ): Pair<ShapeKind, GameColor> {
        val differInBoth = when {
            stage <= 2 -> true
            stage <= 5 -> random.nextFloat() >= 0.6f
            else -> false
        }
        val otherShapes = ShapeKind.entries.filter { it != targetShape }
        val otherColors = GameColor.entries.filter { it != targetColor }
        return when {
            differInBoth -> otherShapes.random(random) to otherColors.random(random)
            random.nextBoolean() -> targetShape to otherColors.random(random)
            else -> otherShapes.random(random) to targetColor
        }
    }

    /** (ستون، سطر) شبکه چیدمان برای [count] شکل؛ لایه UI از همین برای اندازه شکل‌ها استفاده می‌کند. */
    fun gridDimensions(count: Int): Pair<Int, Int> {
        val cols = ceil(sqrt(count * 0.75)).toInt().coerceAtLeast(1)
        val rows = ceil(count.toDouble() / cols).toInt().coerceAtLeast(1)
        return cols to rows
    }

    /** چیدمان شبکه‌ای با کمی جابه‌جایی تصادفی تا اشکال روی هم نیفتند. */
    internal fun layout(count: Int, random: Random): List<Pair<Float, Float>> {
        val (cols, rows) = gridDimensions(count)
        val slots = (0 until rows * cols).shuffled(random).take(count)
        return slots.map { slot ->
            val r = slot / cols
            val c = slot % cols
            val jitterX = (random.nextFloat() - 0.5f) * 0.4f
            val jitterY = (random.nextFloat() - 0.5f) * 0.4f
            Pair((c + 0.5f + jitterX) / cols, (r + 0.5f + jitterY) / rows)
        }
    }
}

sealed interface FocusAnswer {
    data class Correct(val points: Int) : FocusAnswer
    data object Wrong : FocusAnswer
    data object Ignored : FocusAnswer
}

class FocusSession(private val random: Random = Random.Default) {
    var stage: Int = 0
        private set
    var score: Int = 0
        private set
    var correct: Int = 0
        private set
    var wrong: Int = 0
        private set
    var timeouts: Int = 0
        private set
    var current: FocusRound? = null
        private set

    private var correctTimeSum = 0L

    /** میانگین زمان پاسخ‌های درست (میلی‌ثانیه)؛ بدون پاسخ درست ۰. */
    val averageCorrectTimeMs: Int
        get() = if (correct == 0) 0 else (correctTimeSum / correct).toInt()

    val isFinished: Boolean get() = stage >= FocusLogic.STAGES && current == null

    val accuracyPercent: Int get() = correct * 100 / FocusLogic.STAGES

    val performance: Int get() = Scoring.normalize(score, Scoring.FOCUS_REFERENCE_SCORE)

    fun nextRound(): FocusRound? {
        if (current != null || stage >= FocusLogic.STAGES) return null
        stage++
        return FocusLogic.generate(stage, random).also { current = it }
    }

    fun answer(index: Int, remainingMs: Long): FocusAnswer {
        val round = current ?: return FocusAnswer.Ignored
        current = null
        return if (index == round.targetIndex) {
            val points = FocusLogic.correctPoints(remainingMs, round.timeLimitMs)
            correctTimeSum += (round.timeLimitMs - remainingMs).coerceIn(0L, round.timeLimitMs)
            correct++
            score += points
            FocusAnswer.Correct(points)
        } else {
            wrong++
            penalize()
            FocusAnswer.Wrong
        }
    }

    fun timeout() {
        if (current == null) return
        current = null
        timeouts++
        penalize()
    }

    private fun penalize() {
        score = (score - FocusLogic.WRONG_PENALTY).coerceAtLeast(0)
    }
}
