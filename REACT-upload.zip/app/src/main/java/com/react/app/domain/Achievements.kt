package com.react.app.domain

/** تصویر لحظه‌ای از پیشرفت کاربر که شرط‌های دستاوردها روی آن بررسی می‌شود. */
data class ProgressSnapshot(
    val totalTests: Int,
    val successfulTests: Int,
    /** سریع‌ترین زمان یک دور واکنش (میلی‌ثانیه)؛ ۰ یعنی هنوز ثبت نشده. */
    val bestReactionRoundMs: Int,
    val bestMemoryRounds: Int,
    val bestAccuracy: Int,
    /** تعداد آزمون موفق پیاپی تا همین لحظه. */
    val successStreak: Int,
    val playedTypes: Set<GameType>,
    val xp: Int,
) {
    companion object {
        /** مسیر اصلی برنامه: ساخت از وضعیت ماندگار (پروفایل و رکوردها)، مستقل از تاریخچه. */
        fun from(profile: Profile, records: List<RecordSnapshot>): ProgressSnapshot = ProgressSnapshot(
            totalTests = profile.totalTests,
            successfulTests = profile.successfulTests,
            bestReactionRoundMs = records.firstOrNull { it.gameType == GameType.REACTION }?.bestSecondary ?: 0,
            bestMemoryRounds = records.firstOrNull { it.gameType == GameType.MEMORY }?.bestMain ?: 0,
            bestAccuracy = records.maxOfOrNull { it.bestAccuracy } ?: 0,
            successStreak = profile.successStreak,
            playedTypes = records.map { it.gameType }.toSet(),
            xp = profile.xp,
        )

        fun from(results: List<ResultRecord>, xp: Int): ProgressSnapshot = ProgressSnapshot(
            totalTests = results.size,
            successfulTests = results.count { it.success },
            bestReactionRoundMs = results.filter { it.gameType == GameType.REACTION && it.bestValue > 0 }
                .minOfOrNull { it.bestValue } ?: 0,
            bestMemoryRounds = results.filter { it.gameType == GameType.MEMORY }
                .maxOfOrNull { it.mainValue } ?: 0,
            bestAccuracy = results.maxOfOrNull { it.accuracy } ?: 0,
            successStreak = results.take(Achievement.STREAK_TARGET).map { it.success }.takeWhile { it }.size,
            playedTypes = results.map { it.gameType }.toSet(),
            xp = xp,
        )
    }
}

/** هر دستاورد یک شرط مشخص و قابل بررسی دارد (توضیح کاربر‌پسند در [description] است). */
enum class Achievement(
    val title: String,
    val description: String,
    private val rule: (ProgressSnapshot) -> Boolean,
) {
    FIRST_TEST("اولین آزمون", "اولین آزمون خود را کامل کن", { it.totalTests >= 1 }),
    TEN_SUCCESSES("۱۰ آزمون موفق", "در مجموع ۱۰ آزمون موفق انجام بده", { it.successfulTests >= 10 }),
    LIGHTNING("واکنش زیر ۲۵۰ میلی‌ثانیه", "در یک دور آزمون واکنش، زمانی کمتر از ۲۵۰ میلی‌ثانیه ثبت کن", {
        it.bestReactionRoundMs in 1 until 250
    }),
    MEMORY_TEN("حافظه سطح ۱۰", "در آزمون حافظه ۱۰ مرحله را کامل کن", { it.bestMemoryRounds >= 10 }),
    STREAK_FIVE("۵ آزمون متوالی موفق", "پنج آزمون پشت‌سرهم موفق باش", { it.successStreak >= STREAK_TARGET }),
    ACCURACY_90("دقت بالای ۹۰ درصد", "در یک آزمون دقت بالای ۹۰ درصد داشته باش", { it.bestAccuracy > 90 }),
    ALL_ROUNDER("همه‌فن‌حریف", "هر پنج آزمون را حداقل یک‌بار انجام بده", {
        it.playedTypes.size == GameType.entries.size
    }),
    XP_1000("هزار XP", "به ۱۰۰۰ امتیاز تجربه برس", { it.xp >= 1000 });

    fun isUnlockedBy(snapshot: ProgressSnapshot): Boolean = rule(snapshot)

    companion object {
        const val STREAK_TARGET = 5

        fun fromId(id: String): Achievement? = entries.firstOrNull { it.name == id }
    }
}

object AchievementEngine {
    /** دستاوردهایی که با این وضعیت باز می‌شوند و قبلاً باز نشده‌اند. */
    fun newlyUnlocked(snapshot: ProgressSnapshot, alreadyUnlocked: Set<String>): List<Achievement> =
        Achievement.entries.filter { it.name !in alreadyUnlocked && it.isUnlockedBy(snapshot) }
}
