package com.react.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ResultDao {
    @Insert
    suspend fun insert(result: TestResultEntity): Long

    /** برای کنترل مصرف حافظه فقط ۵۰۰ نتیجه آخر خوانده می‌شود. */
    @Query("SELECT * FROM test_results ORDER BY createdAt DESC, id DESC LIMIT 500")
    fun observeRecent(): Flow<List<TestResultEntity>>

    @Query("DELETE FROM test_results")
    suspend fun clear()
}

@Dao
interface RecordDao {
    @Query("SELECT * FROM records")
    fun observeAll(): Flow<List<RecordEntity>>

    @Query("SELECT * FROM records")
    suspend fun getAll(): List<RecordEntity>

    @Query("SELECT * FROM records WHERE gameType = :gameType")
    suspend fun get(gameType: String): RecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: RecordEntity)
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements")
    fun observeAll(): Flow<List<AchievementEntity>>

    @Query("SELECT id FROM achievements")
    suspend fun getIds(): List<String>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(achievement: AchievementEntity)
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profile WHERE id = 1")
    fun observe(): Flow<ProfileEntity?>

    @Query("SELECT * FROM profile WHERE id = 1")
    suspend fun get(): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: ProfileEntity)
}
