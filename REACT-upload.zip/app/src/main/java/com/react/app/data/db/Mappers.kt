package com.react.app.data.db

import com.react.app.domain.GameType
import com.react.app.domain.Profile
import com.react.app.domain.RecordSnapshot
import com.react.app.domain.ResultRecord

/** ردیف‌های با gameType ناشناخته (مثلاً از نسخه‌های بعدی) نادیده گرفته می‌شوند. */
fun TestResultEntity.toDomain(): ResultRecord? {
    val type = GameType.fromKey(gameType) ?: return null
    return ResultRecord(id, type, score, performance, success, accuracy, mainValue, bestValue, xpGained, createdAt)
}

fun RecordEntity.toDomain(): RecordSnapshot? {
    val type = GameType.fromKey(gameType) ?: return null
    return RecordSnapshot(type, bestMain, bestSecondary, bestScore, bestAccuracy)
}

fun RecordSnapshot.toEntity(updatedAt: Long) =
    RecordEntity(gameType.name, bestMain, bestSecondary, bestScore, bestAccuracy, updatedAt)

fun ProfileEntity.toDomain() = Profile(name, avatar, xp, totalTests, successfulTests, successStreak)

fun Profile.toEntity() = ProfileEntity(
    id = 1,
    name = name,
    avatar = avatar,
    xp = xp,
    level = level.ordinal,
    totalTests = totalTests,
    successfulTests = successfulTests,
    successStreak = successStreak,
)
