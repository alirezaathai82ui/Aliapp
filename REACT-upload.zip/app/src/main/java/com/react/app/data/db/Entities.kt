package com.react.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** هر ردیف یک آزمون انجام‌شده است (تاریخچه). معنی mainValue/bestValue در domain/Records.kt (NewResult) آمده است. */
@Entity(
    tableName = "test_results",
    indices = [Index("gameType"), Index("createdAt")],
)
data class TestResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameType: String,
    val score: Int,
    val performance: Int,
    val success: Boolean,
    val accuracy: Int,
    val mainValue: Int,
    val bestValue: Int,
    val xpGained: Int,
    /** زمان تقویمی ثبت (epoch میلی‌ثانیه) برای نمایش تاریخ و ساعت. */
    val createdAt: Long,
)

/** بهترین‌های شخصی هر بازی؛ با پاک کردن تاریخچه حذف نمی‌شود. */
@Entity(tableName = "records")
data class RecordEntity(
    @PrimaryKey val gameType: String,
    val bestMain: Int,
    val bestSecondary: Int,
    val bestScore: Int,
    val bestAccuracy: Int,
    val updatedAt: Long,
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val unlockedAt: Long,
)

/** همیشه فقط یک ردیف با id=1 دارد. */
@Entity(tableName = "profile")
data class ProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val avatar: Int,
    val xp: Int,
    /** اندیس RankLevel؛ هنگام خواندن از روی xp هم قابل بازسازی است. */
    val level: Int,
    val totalTests: Int,
    val successfulTests: Int,
    val successStreak: Int,
)
