package com.react.app.domain

/**
 * قواعد مشترک امتیازدهی.
 *
 * هر آزمون یک «عملکرد» (performance) بین ۰ تا ۱۰۰ دارد. موفقیت و XP از همین عدد مشتق می‌شوند.
 * مقادیر مرجع (REFERENCE) ثابت‌های قابل تنظیم برای نرمال‌سازی امتیاز خام هر بازی هستند.
 */
object Scoring {
    /** حداقل عملکرد برای «آزمون موفق». */
    const val SUCCESS_PERFORMANCE = 50

    const val FOCUS_REFERENCE_SCORE = 100
    const val AIM_REFERENCE_SCORE = 250
    const val STROOP_REFERENCE_SCORE = 200

    fun clampPercent(value: Int): Int = value.coerceIn(0, 100)

    fun normalize(score: Int, reference: Int): Int = clampPercent(score * 100 / reference)

    fun isSuccess(performance: Int): Boolean = performance >= SUCCESS_PERFORMANCE

    /** XP هر آزمون: ۱۰ امتیاز شرکت + تا ۲۰ بر اساس عملکرد + ۱۰ برای موفقیت (حداکثر ۴۰). */
    fun xpFor(performance: Int, success: Boolean): Int =
        10 + clampPercent(performance) / 5 + if (success) 10 else 0
}

enum class RankLevel(val title: String, val minXp: Int) {
    NOVICE("تازه‌کار", 0),
    BEGINNER("مبتدی", 150),
    INTERMEDIATE("متوسط", 450),
    PRO("حرفه‌ای", 1000),
    MASTER("استاد", 2000),
    ELITE("نخبه", 3500),
}

object LevelSystem {
    fun levelFor(xp: Int): RankLevel = RankLevel.entries.last { xp >= it.minXp }

    fun next(level: RankLevel): RankLevel? = RankLevel.entries.getOrNull(level.ordinal + 1)

    /** پیشرفت در سطح فعلی (۰..۱). در بالاترین سطح همیشه ۱ است. */
    fun progress(xp: Int): Float {
        val current = levelFor(xp)
        val next = next(current) ?: return 1f
        return ((xp - current.minXp).toFloat() / (next.minXp - current.minXp)).coerceIn(0f, 1f)
    }

    /** XP لازم تا سطح بعد؛ در بالاترین سطح ۰. */
    fun xpToNext(xp: Int): Int {
        val next = next(levelFor(xp)) ?: return 0
        return (next.minXp - xp).coerceAtLeast(0)
    }
}
