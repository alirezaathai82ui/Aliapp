package com.react.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TestResultEntity::class,
        RecordEntity::class,
        AchievementEntity::class,
        ProfileEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class ReactDatabase : RoomDatabase() {
    abstract fun resultDao(): ResultDao
    abstract fun recordDao(): RecordDao
    abstract fun achievementDao(): AchievementDao
    abstract fun profileDao(): ProfileDao

    companion object {
        const val NAME = "react.db"

        fun create(context: Context): ReactDatabase =
            Room.databaseBuilder(context.applicationContext, ReactDatabase::class.java, NAME).build()
    }
}
