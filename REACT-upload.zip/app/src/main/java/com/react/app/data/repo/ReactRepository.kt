package com.react.app.data.repo

import androidx.room.withTransaction
import com.react.app.data.db.AchievementEntity
import com.react.app.data.db.ReactDatabase
import com.react.app.data.db.TestResultEntity
import com.react.app.data.db.toDomain
import com.react.app.data.db.toEntity
import com.react.app.data.prefs.SettingsStore
import com.react.app.domain.Achievement
import com.react.app.domain.AchievementEngine
import com.react.app.domain.NewResult
import com.react.app.domain.Profile
import com.react.app.domain.ProgressSnapshot
import com.react.app.domain.RecordOutcome
import com.react.app.domain.RecordRules
import com.react.app.domain.RecordSnapshot
import com.react.app.domain.ResultRecord
import com.react.app.domain.Scoring
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ReactRepository(
    private val db: ReactDatabase,
    private val settings: SettingsStore,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val resultDao = db.resultDao()
    private val recordDao = db.recordDao()
    private val achievementDao = db.achievementDao()
    private val profileDao = db.profileDao()

    val profile: Flow<Profile> = profileDao.observe().map { it?.toDomain() ?: Profile() }

    /** جدیدترین اول (حداکثر ۵۰۰ مورد). */
    val results: Flow<List<ResultRecord>> =
        resultDao.observeRecent().map { rows -> rows.mapNotNull { it.toDomain() } }

    val records: Flow<List<RecordSnapshot>> =
        recordDao.observeAll().map { rows -> rows.mapNotNull { it.toDomain() } }

    /** دستاوردهای بازشده و زمان باز شدن آن‌ها. */
    val achievements: Flow<Map<Achievement, Long>> = achievementDao.observeAll().map { rows ->
        rows.mapNotNull { row -> Achievement.fromId(row.id)?.let { it to row.unlockedAt } }.toMap()
    }

    /**
     * ثبت اتمیک یک آزمون: تاریخچه، رکورد، XP و سطح، شمارنده‌ها و دستاوردها در یک تراکنش.
     * اگر برنامه وسط کار بسته شود، یا همه ذخیره می‌شود یا هیچ‌کدام.
     */
    suspend fun recordResult(result: NewResult): RecordOutcome = db.withTransaction {
        val now = clock()
        val before = profileDao.get()?.toDomain() ?: Profile()
        val oldRecord = recordDao.get(result.gameType.name)?.toDomain()
        val xp = Scoring.xpFor(result.performance, result.success)

        resultDao.insert(
            TestResultEntity(
                gameType = result.gameType.name,
                score = result.score,
                performance = result.performance,
                success = result.success,
                accuracy = result.accuracy,
                mainValue = result.mainValue,
                bestValue = result.bestValue,
                xpGained = xp,
                createdAt = now,
            ),
        )

        val mergedRecord = RecordRules.merge(oldRecord, result)
        recordDao.upsert(mergedRecord.toEntity(now))

        val after = before.copy(
            xp = before.xp + xp,
            totalTests = before.totalTests + 1,
            successfulTests = before.successfulTests + if (result.success) 1 else 0,
            successStreak = if (result.success) before.successStreak + 1 else 0,
        )

        val unlockedIds = achievementDao.getIds().toSet()
        val allRecords = recordDao.getAll().mapNotNull { it.toDomain() }
        val newlyUnlocked = AchievementEngine.newlyUnlocked(ProgressSnapshot.from(after, allRecords), unlockedIds)
        newlyUnlocked.forEach { achievementDao.insert(AchievementEntity(it.name, now)) }

        profileDao.upsert(after.toEntity())

        RecordOutcome(
            xpGained = xp,
            totalXp = after.xp,
            previousLevel = before.level,
            newLevel = after.level,
            newAchievements = newlyUnlocked,
            brokeRecord = mergedRecord != oldRecord,
        )
    }

    suspend fun updateProfile(name: String, avatar: Int) {
        val current = profileDao.get()?.toDomain() ?: Profile()
        profileDao.upsert(
            current.copy(
                name = Profile.sanitizeName(name),
                avatar = avatar.coerceIn(0, Profile.AVATAR_COUNT - 1),
            ).toEntity(),
        )
    }

    /** فقط تاریخچه نتایج پاک می‌شود؛ رکوردها، XP، سطح، دستاوردها و پروفایل حفظ می‌شوند. */
    suspend fun clearHistory() {
        resultDao.clear()
    }

    /** بازنشانی کامل: همه جدول‌ها و تنظیمات به حالت اولیه برمی‌گردند. */
    suspend fun resetAll() {
        withContext(Dispatchers.IO) { db.clearAllTables() }
        settings.reset()
    }
}
