package com.react.app.ui.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.react.app.ReactApp
import com.react.app.domain.GameType
import com.react.app.ui.screens.AimScreen
import com.react.app.ui.screens.FocusScreen
import com.react.app.ui.screens.HomeScreen
import com.react.app.ui.screens.MemoryScreen
import com.react.app.ui.screens.ProfileScreen
import com.react.app.ui.screens.ReactionScreen
import com.react.app.ui.screens.SettingsScreen
import com.react.app.ui.screens.SplashScreen
import com.react.app.ui.screens.StatsScreen
import com.react.app.ui.screens.StroopScreen
import com.react.app.ui.viewmodel.AimViewModel
import com.react.app.ui.viewmodel.FocusViewModel
import com.react.app.ui.viewmodel.HomeViewModel
import com.react.app.ui.viewmodel.MemoryViewModel
import com.react.app.ui.viewmodel.ProfileViewModel
import com.react.app.ui.viewmodel.ReactViewModelFactory
import com.react.app.ui.viewmodel.ReactionViewModel
import com.react.app.ui.viewmodel.SettingsViewModel
import com.react.app.ui.viewmodel.StatsViewModel
import com.react.app.ui.viewmodel.StroopViewModel

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val STATS = "stats"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"

    fun game(type: GameType) = "game/${type.name}"
    const val GAME_PATTERN = "game/{type}"
}

@Composable
fun ReactNavHost() {
    val nav = rememberNavController()
    val app = LocalContext.current.applicationContext as ReactApp
    val factory = remember { ReactViewModelFactory(app.container) }

    NavHost(navController = nav, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(onDone = {
                nav.navigate(Routes.HOME) { popUpTo(Routes.SPLASH) { inclusive = true } }
            })
        }
        composable(Routes.HOME) {
            HomeScreen(
                vm = viewModel<HomeViewModel>(factory = factory),
                onGame = { nav.navigate(Routes.game(it)) },
                onStats = { nav.navigate(Routes.STATS) },
                onProfile = { nav.navigate(Routes.PROFILE) },
                onSettings = { nav.navigate(Routes.SETTINGS) },
            )
        }
        composable(Routes.STATS) { StatsScreen(viewModel<StatsViewModel>(factory = factory), onBack = { nav.popBackStack() }) }
        composable(Routes.PROFILE) { ProfileScreen(viewModel<ProfileViewModel>(factory = factory), onBack = { nav.popBackStack() }) }
        composable(Routes.SETTINGS) {
            SettingsScreen(viewModel<SettingsViewModel>(factory = factory), onBack = { nav.popBackStack() })
        }
        composable(Routes.GAME_PATTERN) { entry ->
            val back = { nav.popBackStack(); Unit }
            when (GameType.fromKey(entry.arguments?.getString("type").orEmpty())) {
                GameType.REACTION -> ReactionScreen(viewModel<ReactionViewModel>(factory = factory), back)
                GameType.MEMORY -> MemoryScreen(viewModel<MemoryViewModel>(factory = factory), back)
                GameType.FOCUS -> FocusScreen(viewModel<FocusViewModel>(factory = factory), back)
                GameType.AIM -> AimScreen(viewModel<AimViewModel>(factory = factory), back)
                GameType.STROOP -> StroopScreen(viewModel<StroopViewModel>(factory = factory), back)
                null -> LaunchedEffect(Unit) { back() }
            }
        }
    }
}
