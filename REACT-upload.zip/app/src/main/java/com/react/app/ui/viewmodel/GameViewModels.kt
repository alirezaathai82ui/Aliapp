package com.react.app.ui.viewmodel

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.react.app.AppContainer
import com.react.app.domain.AimEngine
import com.react.app.domain.AimTap
import com.react.app.domain.Cell
import com.react.app.domain.FocusAnswer
import com.react.app.domain.FocusRound
import com.react.app.domain.FocusSession
import com.react.app.domain.GameColor
import com.react.app.domain.MemoryLogic
import com.react.app.domain.MemorySession
import com.react.app.domain.MemoryTap
import com.react.app.domain.NewResult
import com.react.app.domain.ReactionLogic
import com.react.app.domain.ReactionSession
import com.react.app.domain.ReactionSummary
import com.react.app.domain.ReactionTouch
import com.react.app.domain.RecordOutcome
import com.react.app.domain.ResultFactory
import com.react.app.domain.StroopAnswer
import com.react.app.domain.StroopQuestion
import com.react.app.domain.StroopSession
import com.react.app.util.SoundEffect
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

/** پایه مشترک بازی‌ها: ثبت نتیجه (اتمیک، در Room) و پخش صدا. */
abstract class GameViewModel(protected val container: AppContainer) : ViewModel() {
    private val _outcome = MutableStateFlow<RecordOutcome?>(null)
    val outcome: StateFlow<RecordOutcome?> = _outcome.asStateFlow()

    protected var job: Job? = null

    protected fun save(result: NewResult) {
        viewModelScope.launch {
            val saved = withContext(NonCancellable) { container.repository.recordResult(result) }
            _outcome.value = saved
            when {
                saved.leveledUp -> sfx(SoundEffect.LEVEL_UP)
                saved.newAchievements.isNotEmpty() -> sfx(SoundEffect.ACHIEVEMENT)
            }
        }
    }

    protected fun clearOutcome() {
        _outcome.value = null
    }

    protected fun sfx(effect: SoundEffect, haptic: Boolean = true) = container.feedback.play(effect, haptic)

    /** با رفتن برنامه به پس‌زمینه بازی بدون ثبت نتیجه لغو و به صفحه شروع برمی‌گردد. */
    abstract fun onLeave()
}

// ───────────────────────────── تست سرعت واکنش ─────────────────────────────

enum class ReactionPhase { INTRO, WAITING, GO, RESULT, FALSE_START, FINISHED }

data class ReactionUi(
    val phase: ReactionPhase = ReactionPhase.INTRO,
    val completedRounds: Int = 0,
    val lastMs: Int? = null,
    val falseStarts: Int = 0,
    val summary: ReactionSummary? = null,
)

class ReactionViewModel(container: AppContainer) : GameViewModel(container) {
    private var session = ReactionSession()
    private val random = Random.Default
    private val _ui = MutableStateFlow(ReactionUi())
    val ui: StateFlow<ReactionUi> = _ui.asStateFlow()

    fun start() {
        job?.cancel()
        session = ReactionSession()
        clearOutcome()
        sfx(SoundEffect.START)
        beginRound()
    }

    private fun beginRound() {
        session.beginWaiting()
        publish(ReactionPhase.WAITING)
        job = viewModelScope.launch {
            delay(ReactionLogic.randomDelayMs(random))
            session.showGreen(SystemClock.elapsedRealtimeNanos())
            publish(ReactionPhase.GO)
            delay(ReactionLogic.TIMEOUT_MS.toLong())
            handle(session.timeout())
        }
    }

    /** لمس صفحه؛ زمان از ساعت monotonic خوانده می‌شود، نه ساعت تقویمی. */
    fun onTouch() {
        val result = session.touch(SystemClock.elapsedRealtimeNanos())
        if (result !is ReactionTouch.Ignored) {
            job?.cancel()
            handle(result)
        }
    }

    private fun handle(result: ReactionTouch) {
        when (result) {
            ReactionTouch.Ignored -> Unit
            ReactionTouch.FalseStart -> {
                sfx(SoundEffect.WRONG)
                publish(ReactionPhase.FALSE_START)
                job = viewModelScope.launch { delay(1_500); beginRound() }
            }
            is ReactionTouch.Recorded -> {
                sfx(SoundEffect.TAP)
                if (result.finished) {
                    finish()
                } else {
                    publish(ReactionPhase.RESULT)
                    job = viewModelScope.launch { delay(1_200); beginRound() }
                }
            }
        }
    }

    private fun finish() {
        val summary = session.summary()
        publish(ReactionPhase.FINISHED, summary)
        sfx(SoundEffect.FINISH)
        save(ResultFactory.reaction(summary))
    }

    private fun publish(phase: ReactionPhase, summary: ReactionSummary? = null) {
        _ui.value = ReactionUi(phase, session.completedRounds, session.lastTimeMs, session.falseStarts, summary)
    }

    override fun onLeave() {
        if (_ui.value.phase == ReactionPhase.FINISHED || _ui.value.phase == ReactionPhase.INTRO) return
        job?.cancel()
        session = ReactionSession()
        _ui.value = ReactionUi()
    }
}

// ───────────────────────────── تست حافظه ─────────────────────────────

enum class MemoryPhase { INTRO, SHOWING, INPUT, OVER }

data class MemoryUi(
    val phase: MemoryPhase = MemoryPhase.INTRO,
    val gridSize: Int = 3,
    val lit: Cell? = null,
    val pressed: Cell? = null,
    val wrong: Cell? = null,
    val round: Int = 0,
    val completedRounds: Int = 0,
)

class MemoryViewModel(container: AppContainer) : GameViewModel(container) {
    private var session = MemorySession()
    private val _ui = MutableStateFlow(MemoryUi())
    val ui: StateFlow<MemoryUi> = _ui.asStateFlow()

    fun start() {
        job?.cancel()
        session = MemorySession()
        clearOutcome()
        sfx(SoundEffect.START)
        job = viewModelScope.launch { playRound() }
    }

    private suspend fun playRound() {
        val sequence = session.startNextRound()
        val round = session.round
        update { it.copy(phase = MemoryPhase.SHOWING, gridSize = session.gridSize, lit = null, pressed = null, round = round, completedRounds = session.completedRounds) }
        delay(600)
        for (cell in sequence) {
            update { it.copy(lit = cell) }
            sfx(SoundEffect.TAP, haptic = false)
            delay(MemoryLogic.flashDurationMs(round))
            update { it.copy(lit = null) }
            delay(MemoryLogic.gapMs(round))
        }
        update { it.copy(phase = MemoryPhase.INPUT) }
    }

    fun tap(cell: Cell) {
        if (_ui.value.phase != MemoryPhase.INPUT) return
        when (val result = session.tap(cell)) {
            MemoryTap.Ignored -> Unit
            MemoryTap.Correct -> flashPressed(cell)
            is MemoryTap.RoundComplete -> {
                update { it.copy(pressed = cell, completedRounds = result.completedRounds, phase = MemoryPhase.SHOWING) }
                sfx(SoundEffect.TAP)
                job = viewModelScope.launch { delay(700); playRound() }
            }
            MemoryTap.Wrong -> {
                job?.cancel()
                sfx(SoundEffect.WRONG)
                update { it.copy(phase = MemoryPhase.OVER, wrong = cell, pressed = null, lit = null) }
                save(ResultFactory.memory(session))
            }
        }
    }

    private fun flashPressed(cell: Cell) {
        sfx(SoundEffect.TAP)
        update { it.copy(pressed = cell) }
        viewModelScope.launch {
            delay(140)
            update { if (it.pressed == cell) it.copy(pressed = null) else it }
        }
    }

    private fun update(block: (MemoryUi) -> MemoryUi) = _ui.update(block)

    override fun onLeave() {
        if (_ui.value.phase == MemoryPhase.INTRO || _ui.value.phase == MemoryPhase.OVER) return
        job?.cancel()
        session = MemorySession()
        _ui.value = MemoryUi()
    }
}

// ───────────────────────────── تست تمرکز ─────────────────────────────

enum class FocusPhase { INTRO, PLAYING, FEEDBACK, FINISHED }

data class FocusUi(
    val phase: FocusPhase = FocusPhase.INTRO,
    val round: FocusRound? = null,
    val remainingMs: Long = 0,
    val score: Int = 0,
    val correct: Int = 0,
    val wrong: Int = 0,
    val lastCorrect: Boolean? = null,
    val chosen: Int? = null,
    val accuracy: Int = 0,
    val averageTimeMs: Int = 0,
    val performance: Int = 0,
)

class FocusViewModel(container: AppContainer) : GameViewModel(container) {
    private var session = FocusSession()
    private var deadline = 0L
    private val _ui = MutableStateFlow(FocusUi())
    val ui: StateFlow<FocusUi> = _ui.asStateFlow()

    fun start() {
        job?.cancel()
        session = FocusSession()
        clearOutcome()
        sfx(SoundEffect.START)
        nextRound()
    }

    private fun nextRound() {
        val round = session.nextRound()
        if (round == null) {
            finish()
            return
        }
        deadline = SystemClock.elapsedRealtime() + round.timeLimitMs
        _ui.value = snapshot(FocusPhase.PLAYING, round, remaining = round.timeLimitMs)
        job = viewModelScope.launch {
            while (true) {
                val remaining = deadline - SystemClock.elapsedRealtime()
                if (remaining <= 0) {
                    session.timeout()
                    sfx(SoundEffect.WRONG)
                    _ui.value = snapshot(FocusPhase.FEEDBACK, round, lastCorrect = false)
                    delay(900)
                    nextRound()
                    return@launch
                }
                _ui.update { it.copy(remainingMs = remaining) }
                delay(50)
            }
        }
    }

    fun answer(index: Int) {
        val state = _ui.value
        val round = state.round ?: return
        if (state.phase != FocusPhase.PLAYING) return
        job?.cancel()
        val remaining = (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(0)
        val correct = session.answer(index, remaining) is FocusAnswer.Correct
        sfx(if (correct) SoundEffect.TAP else SoundEffect.WRONG)
        _ui.value = snapshot(FocusPhase.FEEDBACK, round, lastCorrect = correct, chosen = index)
        job = viewModelScope.launch { delay(700); nextRound() }
    }

    private fun finish() {
        sfx(SoundEffect.FINISH)
        _ui.value = snapshot(FocusPhase.FINISHED, null)
        save(ResultFactory.focus(session))
    }

    private fun snapshot(
        phase: FocusPhase,
        round: FocusRound?,
        remaining: Long = 0,
        lastCorrect: Boolean? = null,
        chosen: Int? = null,
    ) = FocusUi(
        phase = phase, round = round, remainingMs = remaining, score = session.score,
        correct = session.correct, wrong = session.wrong + session.timeouts,
        lastCorrect = lastCorrect, chosen = chosen,
        accuracy = session.accuracyPercent, averageTimeMs = session.averageCorrectTimeMs,
        performance = session.performance,
    )

    override fun onLeave() {
        if (_ui.value.phase == FocusPhase.INTRO || _ui.value.phase == FocusPhase.FINISHED) return
        job?.cancel()
        session = FocusSession()
        _ui.value = FocusUi()
    }
}

// ───────────────────────────── تست دقت ─────────────────────────────

enum class AimPhase { INTRO, PLAYING, FINISHED }

class AimTargetUi(val id: Int, val x: Float, val y: Float, val radius: Float, val ageFraction: Float)

data class AimUi(
    val phase: AimPhase = AimPhase.INTRO,
    val targets: List<AimTargetUi> = emptyList(),
    val score: Int = 0,
    val hits: Int = 0,
    val missTaps: Int = 0,
    val expired: Int = 0,
    val remainingMs: Long = AimEngine.DURATION_MS,
    val accuracy: Int = 0,
    val performance: Int = 0,
)

class AimViewModel(container: AppContainer) : GameViewModel(container) {
    private var engine: AimEngine? = null
    private var startedAt = 0L
    private val _ui = MutableStateFlow(AimUi())
    val ui: StateFlow<AimUi> = _ui.asStateFlow()

    fun start(widthPx: Float, heightPx: Float, density: Float) {
        if (widthPx <= 0f || heightPx <= 0f) return
        job?.cancel()
        clearOutcome()
        val e = AimEngine(widthPx, heightPx, density)
        engine = e
        sfx(SoundEffect.START)
        startedAt = SystemClock.elapsedRealtime()
        job = viewModelScope.launch {
            while (true) {
                val now = SystemClock.elapsedRealtime() - startedAt
                e.update(now)
                if (e.isFinished(now)) {
                    finish(e)
                    break
                }
                publish(e, AimPhase.PLAYING, now)
                delay(16)
            }
        }
    }

    fun tap(x: Float, y: Float) {
        val e = engine ?: return
        if (_ui.value.phase != AimPhase.PLAYING) return
        when (e.tap(x, y)) {
            is AimTap.Hit -> sfx(SoundEffect.TAP)
            AimTap.Miss -> sfx(SoundEffect.WRONG)
        }
        publish(e, AimPhase.PLAYING, SystemClock.elapsedRealtime() - startedAt)
    }

    private fun finish(e: AimEngine) {
        publish(e, AimPhase.FINISHED, AimEngine.DURATION_MS)
        sfx(SoundEffect.FINISH)
        save(ResultFactory.aim(e))
    }

    private fun publish(e: AimEngine, phase: AimPhase, nowMs: Long) {
        _ui.value = AimUi(
            phase = phase,
            targets = if (phase == AimPhase.PLAYING) {
                e.targets.map {
                    AimTargetUi(it.id, it.x, it.y, it.radius, ((nowMs - it.bornMs).toFloat() / it.lifetimeMs).coerceIn(0f, 1f))
                }
            } else {
                emptyList()
            },
            score = e.score, hits = e.hits, missTaps = e.missTaps, expired = e.expired,
            remainingMs = (AimEngine.DURATION_MS - nowMs).coerceAtLeast(0),
            accuracy = e.accuracyPercent, performance = e.performance,
        )
    }

    override fun onLeave() {
        if (_ui.value.phase != AimPhase.PLAYING) return
        job?.cancel()
        engine = null
        _ui.value = AimUi()
    }
}

// ───────────────────────────── چالش رنگ‌ها ─────────────────────────────

enum class StroopPhase { INTRO, PLAYING, FEEDBACK, FINISHED }

data class StroopUi(
    val phase: StroopPhase = StroopPhase.INTRO,
    val question: StroopQuestion? = null,
    val remainingMs: Long = 0,
    val asked: Int = 0,
    val score: Int = 0,
    val correct: Int = 0,
    val wrong: Int = 0,
    val lastCorrect: Boolean? = null,
    val chosen: GameColor? = null,
    val accuracy: Int = 0,
    val averageTimeMs: Int = 0,
    val performance: Int = 0,
)

class StroopViewModel(container: AppContainer) : GameViewModel(container) {
    private var session = StroopSession()
    private var deadline = 0L
    private val _ui = MutableStateFlow(StroopUi())
    val ui: StateFlow<StroopUi> = _ui.asStateFlow()

    fun start() {
        job?.cancel()
        session = StroopSession()
        clearOutcome()
        sfx(SoundEffect.START)
        nextQuestion()
    }

    private fun nextQuestion() {
        val question = session.next()
        if (question == null) {
            finish()
            return
        }
        deadline = SystemClock.elapsedRealtime() + question.timeLimitMs
        _ui.value = snapshot(StroopPhase.PLAYING, question, remaining = question.timeLimitMs)
        job = viewModelScope.launch {
            while (true) {
                val remaining = deadline - SystemClock.elapsedRealtime()
                if (remaining <= 0) {
                    session.timeout()
                    sfx(SoundEffect.WRONG)
                    _ui.value = snapshot(StroopPhase.FEEDBACK, question, lastCorrect = false)
                    delay(600)
                    nextQuestion()
                    return@launch
                }
                _ui.update { it.copy(remainingMs = remaining) }
                delay(50)
            }
        }
    }

    fun answer(color: GameColor) {
        val state = _ui.value
        val question = state.question ?: return
        if (state.phase != StroopPhase.PLAYING) return
        job?.cancel()
        val remaining = (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(0)
        val correct = session.answer(color, remaining) is StroopAnswer.Correct
        sfx(if (correct) SoundEffect.TAP else SoundEffect.WRONG)
        _ui.value = snapshot(StroopPhase.FEEDBACK, question, lastCorrect = correct, chosen = color)
        job = viewModelScope.launch { delay(350); nextQuestion() }
    }

    private fun finish() {
        sfx(SoundEffect.FINISH)
        _ui.value = snapshot(StroopPhase.FINISHED, null)
        save(ResultFactory.stroop(session))
    }

    private fun snapshot(
        phase: StroopPhase,
        question: StroopQuestion?,
        remaining: Long = 0,
        lastCorrect: Boolean? = null,
        chosen: GameColor? = null,
    ) = StroopUi(
        phase = phase, question = question, remainingMs = remaining, asked = session.asked,
        score = session.score, correct = session.correct, wrong = session.wrong,
        lastCorrect = lastCorrect, chosen = chosen, accuracy = session.accuracyPercent,
        averageTimeMs = session.averageCorrectTimeMs, performance = session.performance,
    )

    override fun onLeave() {
        if (_ui.value.phase == StroopPhase.INTRO || _ui.value.phase == StroopPhase.FINISHED) return
        job?.cancel()
        session = StroopSession()
        _ui.value = StroopUi()
    }
}
