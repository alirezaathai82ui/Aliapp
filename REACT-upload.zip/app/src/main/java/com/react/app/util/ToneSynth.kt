package com.react.app.util

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class SoundEffect { START, TAP, WRONG, ACHIEVEMENT, LEVEL_UP, FINISH }

/**
 * افکت‌های صوتی برنامه کاملاً در زمان اجرا از موج سینوسی ساخته می‌شوند؛
 * پس هیچ فایل صوتی با مجوز نامشخص در برنامه نیست و حجم APK هم زیاد نمی‌شود.
 */
object ToneSynth {
    const val SAMPLE_RATE = 22_050

    /** [freqHz] برابر ۰ یعنی سکوت. */
    data class Note(val freqHz: Float, val durationMs: Int, val volume: Float = 0.7f)

    fun sampleCount(durationMs: Int): Int = SAMPLE_RATE * durationMs / 1000

    fun render(notes: List<Note>): ShortArray {
        val out = ShortArray(notes.sumOf { sampleCount(it.durationMs) })
        var pos = 0
        for (note in notes) {
            val count = sampleCount(note.durationMs)
            val attack = (SAMPLE_RATE * 0.004).toInt().coerceAtLeast(1)
            val release = (SAMPLE_RATE * 0.006).toInt().coerceIn(1, count.coerceAtLeast(1))
            for (i in 0 until count) {
                val t = i.toDouble() / SAMPLE_RATE
                var envelope = exp(-2.2 * i / count)
                if (i < attack) envelope *= i.toDouble() / attack
                if (i > count - release) envelope *= (count - i).toDouble() / release
                val wave = if (note.freqHz <= 0f) {
                    0.0
                } else {
                    sin(2 * PI * note.freqHz * t) * 0.8 + sin(4 * PI * note.freqHz * t) * 0.2
                }
                val sample = wave * envelope * note.volume * Short.MAX_VALUE * 0.8
                out[pos + i] = sample.toInt().coerceIn(-32768, 32767).toShort()
            }
            pos += count
        }
        return out
    }
}

object SoundBank {
    fun notes(effect: SoundEffect): List<ToneSynth.Note> = when (effect) {
        SoundEffect.START -> listOf(ToneSynth.Note(660f, 70), ToneSynth.Note(880f, 120))
        SoundEffect.TAP -> listOf(ToneSynth.Note(880f, 60))
        SoundEffect.WRONG -> listOf(ToneSynth.Note(220f, 110), ToneSynth.Note(165f, 200))
        SoundEffect.ACHIEVEMENT -> listOf(
            ToneSynth.Note(523f, 90), ToneSynth.Note(659f, 90),
            ToneSynth.Note(784f, 90), ToneSynth.Note(1046f, 240),
        )
        SoundEffect.LEVEL_UP -> listOf(
            ToneSynth.Note(392f, 100), ToneSynth.Note(523f, 100), ToneSynth.Note(659f, 100),
            ToneSynth.Note(784f, 100), ToneSynth.Note(1046f, 320),
        )
        SoundEffect.FINISH -> listOf(ToneSynth.Note(784f, 110), ToneSynth.Note(587f, 240))
    }
}
