package com.react.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.reactDataStore: DataStore<Preferences> by preferencesDataStore(name = "react_settings")

data class AppSettings(
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    /** در نسخه فعلی فقط فارسی (fa) فعال است. */
    val language: String = "fa",
)

class SettingsStore(context: Context) {
    private val store = context.applicationContext.reactDataStore

    private object Keys {
        val SOUND = booleanPreferencesKey("sound_enabled")
        val VIBRATION = booleanPreferencesKey("vibration_enabled")
        val LANGUAGE = stringPreferencesKey("language")
    }

    val settings: Flow<AppSettings> = store.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { prefs ->
            AppSettings(
                soundEnabled = prefs[Keys.SOUND] ?: true,
                vibrationEnabled = prefs[Keys.VIBRATION] ?: true,
                language = prefs[Keys.LANGUAGE] ?: "fa",
            )
        }

    suspend fun setSoundEnabled(enabled: Boolean) {
        store.edit { it[Keys.SOUND] = enabled }
    }

    suspend fun setVibrationEnabled(enabled: Boolean) {
        store.edit { it[Keys.VIBRATION] = enabled }
    }

    suspend fun reset() {
        store.edit { it.clear() }
    }
}
