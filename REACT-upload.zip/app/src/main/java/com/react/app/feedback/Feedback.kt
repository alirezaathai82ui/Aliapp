package com.react.app.feedback

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.react.app.data.prefs.AppSettings
import com.react.app.util.SoundBank
import com.react.app.util.SoundEffect
import com.react.app.util.ToneSynth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

/**
 * صدا و لرزش بازی. وضعیت روشن/خاموش بودن از تنظیمات (DataStore) خوانده می‌شود.
 * هیچ‌یک از خطاهای سخت‌افزاری (نبود موتور لرزش، مشکل AudioTrack) باعث کرش نمی‌شود.
 */
class Feedback(context: Context, settings: Flow<AppSettings>, scope: CoroutineScope) {
    @Volatile private var soundOn = true
    @Volatile private var vibrationOn = true

    private val player = SoundPlayer()
    private val vibrator: Vibrator? = createVibrator(context.applicationContext)

    init {
        scope.launch {
            settings.collect {
                soundOn = it.soundEnabled
                vibrationOn = it.vibrationEnabled
            }
        }
        scope.launch(Dispatchers.Default) {
            SoundEffect.entries.forEach { player.prepare(it) }
        }
    }

    fun play(effect: SoundEffect, haptic: Boolean = true) {
        if (soundOn) player.play(effect)
        if (haptic && vibrationOn) vibrate(effect)
    }

    private fun vibrate(effect: SoundEffect) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val timings = when (effect) {
            SoundEffect.TAP -> longArrayOf(0, 12)
            SoundEffect.START -> longArrayOf(0, 20)
            SoundEffect.WRONG -> longArrayOf(0, 40, 40, 60)
            SoundEffect.FINISH -> longArrayOf(0, 50)
            SoundEffect.ACHIEVEMENT -> longArrayOf(0, 30, 60, 30, 60, 70)
            SoundEffect.LEVEL_UP -> longArrayOf(0, 40, 50, 40, 50, 100)
        }
        runCatching { v.vibrate(VibrationEffect.createWaveform(timings, -1)) }
    }

    private fun createVibrator(context: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
}

/** هر افکت یک‌بار به PCM تبدیل و در AudioTrack ایستا نگه داشته می‌شود تا پخش مجدد تأخیر کمی داشته باشد. */
private class SoundPlayer {
    private val tracks = HashMap<SoundEffect, AudioTrack>()

    @Synchronized
    fun prepare(effect: SoundEffect) {
        if (!tracks.containsKey(effect)) {
            build(effect)?.let { tracks[effect] = it }
        }
    }

    @Synchronized
    fun play(effect: SoundEffect) {
        prepare(effect)
        val track = tracks[effect] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    private fun build(effect: SoundEffect): AudioTrack? = runCatching {
        val pcm = ToneSynth.render(SoundBank.notes(effect))
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(ToneSynth.SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(pcm, 0, pcm.size)
        track
    }.getOrNull()
}
