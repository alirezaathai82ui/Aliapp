package com.react.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.react.app.domain.GameType
import com.react.app.domain.Profile
import com.react.app.domain.ShapeKind
import com.react.app.ui.theme.ReactColors
import com.react.app.ui.theme.accent
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class UiIcon { BACK, FORWARD, PROFILE, SETTINGS, INFO }

/** آیکن‌های رابط که با Canvas کشیده می‌شوند (بدون وابستگی به کتابخانه آیکن). */
@Composable
fun UiIconImage(
    icon: UiIcon,
    modifier: Modifier = Modifier,
    iconSize: Dp = 24.dp,
    tint: Color = ReactColors.TextPrimary,
) {
    Canvas(modifier.size(iconSize)) {
        val s = this.size.minDimension
        val stroke = Stroke(width = s * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (icon) {
            // در رابط راست‌به‌چپ «بازگشت» به سمت راست و «ادامه» به سمت چپ اشاره می‌کند.
            UiIcon.BACK -> {
                val p = Path().apply {
                    moveTo(s * 0.38f, s * 0.2f); lineTo(s * 0.68f, s * 0.5f); lineTo(s * 0.38f, s * 0.8f)
                }
                drawPath(p, tint, style = stroke)
            }
            UiIcon.FORWARD -> {
                val p = Path().apply {
                    moveTo(s * 0.62f, s * 0.2f); lineTo(s * 0.32f, s * 0.5f); lineTo(s * 0.62f, s * 0.8f)
                }
                drawPath(p, tint, style = stroke)
            }
            UiIcon.PROFILE -> {
                drawCircle(tint, radius = s * 0.17f, center = Offset(s * 0.5f, s * 0.33f), style = stroke)
                drawArc(
                    color = tint, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(s * 0.2f, s * 0.58f), size = Size(s * 0.6f, s * 0.46f), style = stroke,
                )
            }
            UiIcon.SETTINGS -> {
                val c = Offset(s * 0.5f, s * 0.5f)
                drawCircle(tint, radius = s * 0.15f, center = c, style = stroke)
                for (i in 0 until 8) {
                    val a = i * PI / 4
                    val start = Offset(c.x + (cos(a) * s * 0.27f).toFloat(), c.y + (sin(a) * s * 0.27f).toFloat())
                    val end = Offset(c.x + (cos(a) * s * 0.38f).toFloat(), c.y + (sin(a) * s * 0.38f).toFloat())
                    drawLine(tint, start, end, strokeWidth = s * 0.09f, cap = StrokeCap.Round)
                }
            }
            UiIcon.INFO -> {
                drawCircle(tint, radius = s * 0.38f, center = Offset(s * 0.5f, s * 0.5f), style = stroke)
                drawCircle(tint, radius = s * 0.045f, center = Offset(s * 0.5f, s * 0.33f))
                drawLine(tint, Offset(s * 0.5f, s * 0.46f), Offset(s * 0.5f, s * 0.7f), strokeWidth = s * 0.09f, cap = StrokeCap.Round)
            }
        }
    }
}

private val PulsePoints = listOf(
    Offset(0.04f, 0.56f), Offset(0.30f, 0.56f), Offset(0.40f, 0.26f), Offset(0.56f, 0.84f),
    Offset(0.69f, 0.42f), Offset(0.77f, 0.56f), Offset(0.96f, 0.56f),
)

/** نشان REACT: خط ضربان که در لحظه واکنش اوج می‌گیرد. [progress] برای انیمیشن کشیده شدن خط است. */
@Composable
fun ReactLogo(
    modifier: Modifier = Modifier,
    logoSize: Dp = 64.dp,
    progress: Float = 1f,
    color: Color = ReactColors.Green,
) {
    Canvas(modifier.size(logoSize)) {
        val w = this.size.width
        val h = this.size.height
        val full = Path().apply {
            PulsePoints.forEachIndexed { i, p ->
                if (i == 0) moveTo(p.x * w, p.y * h) else lineTo(p.x * w, p.y * h)
            }
        }
        val measure = PathMeasure()
        measure.setPath(full, false)
        val shown = Path()
        measure.getSegment(0f, measure.length * progress.coerceIn(0f, 1f), shown, true)
        val base = this.size.minDimension
        drawPath(shown, color.copy(alpha = 0.25f), style = Stroke(width = base * 0.16f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(shown, color, style = Stroke(width = base * 0.075f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** آیکن اختصاصی هر آزمون. */
@Composable
fun GameIcon(
    type: GameType,
    modifier: Modifier = Modifier,
    iconSize: Dp = 32.dp,
    tint: Color = type.accent(),
) {
    Canvas(modifier.size(iconSize)) { drawGameIcon(type, tint) }
}

fun DrawScope.drawGameIcon(type: GameType, tint: Color) {
    val s = this.size.minDimension
    val stroke = Stroke(width = s * 0.07f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (type) {
        GameType.REACTION -> {
            val bolt = Path().apply {
                moveTo(s * 0.58f, s * 0.06f); lineTo(s * 0.22f, s * 0.56f); lineTo(s * 0.48f, s * 0.56f)
                lineTo(s * 0.40f, s * 0.94f); lineTo(s * 0.78f, s * 0.40f); lineTo(s * 0.52f, s * 0.40f); close()
            }
            drawPath(bolt, tint.copy(alpha = 0.22f))
            drawPath(bolt, tint, style = stroke)
        }
        GameType.MEMORY -> {
            val cell = s * 0.24f
            val gap = s * 0.07f
            val start = (s - 3 * cell - 2 * gap) / 2f
            for (r in 0 until 3) for (c in 0 until 3) {
                val filled = (r + c) % 2 == 0
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(start + c * (cell + gap), start + r * (cell + gap)),
                    size = Size(cell, cell),
                    cornerRadius = CornerRadius(cell * 0.25f),
                    style = if (filled) Fill else Stroke(width = s * 0.045f),
                )
            }
        }
        GameType.FOCUS -> {
            val c = Offset(s / 2f, s / 2f)
            drawCircle(tint, radius = s * 0.40f, center = c, style = stroke)
            drawCircle(tint, radius = s * 0.22f, center = c, style = stroke)
            drawCircle(tint, radius = s * 0.07f, center = c)
        }
        GameType.AIM -> {
            val c = Offset(s / 2f, s / 2f)
            drawCircle(tint, radius = s * 0.30f, center = c, style = stroke)
            val w = s * 0.07f
            drawLine(tint, Offset(c.x, s * 0.04f), Offset(c.x, s * 0.34f), strokeWidth = w, cap = StrokeCap.Round)
            drawLine(tint, Offset(c.x, s * 0.66f), Offset(c.x, s * 0.96f), strokeWidth = w, cap = StrokeCap.Round)
            drawLine(tint, Offset(s * 0.04f, c.y), Offset(s * 0.34f, c.y), strokeWidth = w, cap = StrokeCap.Round)
            drawLine(tint, Offset(s * 0.66f, c.y), Offset(s * 0.96f, c.y), strokeWidth = w, cap = StrokeCap.Round)
            drawCircle(tint, radius = s * 0.05f, center = c)
        }
        GameType.STROOP -> {
            drawCircle(Color(0xFFFF4545).copy(alpha = 0.8f), radius = s * 0.25f, center = Offset(s * 0.38f, s * 0.38f))
            drawCircle(Color(0xFF39FF88).copy(alpha = 0.8f), radius = s * 0.25f, center = Offset(s * 0.62f, s * 0.38f))
            drawCircle(Color(0xFF3DA5FF).copy(alpha = 0.8f), radius = s * 0.25f, center = Offset(s * 0.5f, s * 0.62f))
        }
    }
}

/** رسم شکل‌های بازی تمرکز. [radius] شعاع محیطی شکل است. */
fun DrawScope.drawGameShape(kind: ShapeKind, center: Offset, radius: Float, color: Color) {
    when (kind) {
        ShapeKind.CIRCLE -> drawCircle(color, radius, center)
        ShapeKind.SQUARE -> {
            val h = radius * 0.86f
            drawRoundRect(
                color = color,
                topLeft = Offset(center.x - h, center.y - h),
                size = Size(2 * h, 2 * h),
                cornerRadius = CornerRadius(h * 0.22f),
            )
        }
        ShapeKind.TRIANGLE -> fillPolygon(
            listOf(
                Offset(center.x, center.y - radius),
                Offset(center.x + radius * 0.95f, center.y + radius * 0.72f),
                Offset(center.x - radius * 0.95f, center.y + radius * 0.72f),
            ),
            color,
        )
        ShapeKind.DIAMOND -> fillPolygon(
            listOf(
                Offset(center.x, center.y - radius),
                Offset(center.x + radius * 0.78f, center.y),
                Offset(center.x, center.y + radius),
                Offset(center.x - radius * 0.78f, center.y),
            ),
            color,
        )
        ShapeKind.STAR -> fillPolygon(
            List(10) { i ->
                val angle = -PI / 2 + i * PI / 5
                val r = if (i % 2 == 0) radius else radius * 0.45f
                Offset(center.x + (cos(angle) * r).toFloat(), center.y + (sin(angle) * r).toFloat())
            },
            color,
        )
        ShapeKind.HEXAGON -> fillPolygon(
            List(6) { i ->
                val angle = -PI / 2 + i * PI / 3
                Offset(center.x + (cos(angle) * radius).toFloat(), center.y + (sin(angle) * radius).toFloat())
            },
            color,
        )
    }
}

private fun DrawScope.fillPolygon(points: List<Offset>, color: Color) {
    val path = Path()
    points.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
    path.close()
    drawPath(path, color)
}

private val AvatarAccents = listOf(
    ReactColors.AccentReaction, ReactColors.AccentMemory, ReactColors.AccentFocus, ReactColors.AccentAim,
    ReactColors.AccentStroop, Color(0xFFFF6BB5), Color(0xFF3DA5FF), Color(0xFFE8F0EA),
)

/** آواتارهای داخلی (۸ طرح هندسی)؛ هیچ تصویری از اینترنت یا حافظه گوشی خوانده نمی‌شود. */
@Composable
fun AvatarImage(index: Int, modifier: Modifier = Modifier, avatarSize: Dp = 56.dp) {
    val i = index.coerceIn(0, Profile.AVATAR_COUNT - 1)
    val accent = AvatarAccents[i]
    Box(
        modifier = modifier
            .size(avatarSize)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.35f), ReactColors.Card)))
            .border(1.5.dp, accent.copy(alpha = 0.7f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(avatarSize * 0.55f)) {
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val r = this.size.minDimension * 0.45f
            when (i) {
                in 0..4 -> drawGameIcon(GameType.entries[i], accent)
                5 -> drawGameShape(ShapeKind.STAR, c, r, accent)
                6 -> drawGameShape(ShapeKind.HEXAGON, c, r, accent)
                else -> drawGameShape(ShapeKind.TRIANGLE, c, r, accent)
            }
        }
    }
}
