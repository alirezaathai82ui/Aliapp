package com.react.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.react.app.domain.GameType
import com.react.app.domain.LevelSystem
import com.react.app.domain.ResultRecord
import com.react.app.ui.components.AvatarImage
import com.react.app.ui.components.CenterMessage
import com.react.app.ui.components.GameIcon
import com.react.app.ui.components.GhostButton
import com.react.app.ui.components.LineChart
import com.react.app.ui.components.NeonCard
import com.react.app.ui.components.NeonProgressBar
import com.react.app.ui.components.ReactLogo
import com.react.app.ui.components.ScreenScaffold
import com.react.app.ui.components.SectionTitle
import com.react.app.ui.components.StatTile
import com.react.app.ui.components.UiIcon
import com.react.app.ui.components.UiIconImage
import com.react.app.ui.fa
import com.react.app.ui.msText
import com.react.app.ui.percentText
import com.react.app.ui.summaryText
import com.react.app.ui.theme.ReactColors
import com.react.app.ui.theme.accent
import com.react.app.ui.viewmodel.HomeViewModel
import com.react.app.ui.viewmodel.StatsViewModel
import com.react.app.util.PersianFormat
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.verticalScroll

// ───────────────────────────── Splash ─────────────────────────────

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val draw = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        draw.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        textAlpha.animateTo(1f, tween(450))
        kotlinx.coroutines.delay(400)
        onDone()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(ReactColors.Background)
            .drawBehind {
                drawCircle(
                    Brush.radialGradient(
                        listOf(ReactColors.Green.copy(alpha = 0.22f * draw.value), Color.Transparent),
                        radius = size.minDimension * 0.7f,
                    ),
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            ReactLogo(logoSize = 140.dp, progress = draw.value)
            Spacer(Modifier.height(16.dp))
            Text(
                "REACT",
                color = ReactColors.TextPrimary,
                fontSize = 44.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 8.sp,
                modifier = Modifier.alpha(textAlpha.value),
            )
            Spacer(Modifier.height(6.dp))
            Text("سرعتت رو ثابت کن.", color = ReactColors.Green, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.alpha(textAlpha.value))
        }
    }
}

// ───────────────────────────── Home ─────────────────────────────

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    onGame: (GameType) -> Unit,
    onStats: () -> Unit,
    onProfile: () -> Unit,
    onSettings: () -> Unit,
) {
    val state by vm.state.collectAsState()
    val profile = state.profile
    val summary = state.summary

    Column(
        Modifier
            .fillMaxSize()
            .background(ReactColors.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            ReactLogo(logoSize = 40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("REACT", color = ReactColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp, letterSpacing = 3.sp)
                Text("سرعتت رو ثابت کن.", color = ReactColors.Green, style = MaterialTheme.typography.bodySmall)
            }
            IconBox(UiIcon.PROFILE, onProfile)
            Spacer(Modifier.width(6.dp))
            IconBox(UiIcon.SETTINGS, onSettings)
        }

        Spacer(Modifier.height(22.dp))
        Text("آماده‌ای سرعتت رو بسنجی؟", style = MaterialTheme.typography.headlineMedium, color = ReactColors.TextPrimary)
        Spacer(Modifier.height(14.dp))

        NeonCard(Modifier.fillMaxWidth(), accent = ReactColors.Green, onClick = onProfile) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AvatarImage(profile.avatar, avatarSize = 52.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(profile.name, color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
                    Text("سطح ${profile.level.title} · ${profile.xp.fa()} XP", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(10.dp))
            NeonProgressBar(LevelSystem.progress(profile.xp))
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("بهترین رکورد واکنش", summary.bestReactionMs?.let { msText(it) } ?: "—", Modifier.weight(1f))
            StatTile("آزمون‌های انجام‌شده", summary.totalTests.fa(), Modifier.weight(1f), accent = ReactColors.AccentMemory)
        }
        Spacer(Modifier.height(12.dp))
        NeonCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("امتیاز عملکرد کلی", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                    Text("${summary.overallPerformance.fa()} از ۱۰۰", color = ReactColors.Green, style = MaterialTheme.typography.headlineSmall)
                }
            }
            Spacer(Modifier.height(8.dp))
            NeonProgressBar(summary.overallPerformance / 100f)
            Spacer(Modifier.height(8.dp))
            Text(
                "روش محاسبه: برای هر بازی میانگین عملکرد ۵ آزمون اخیر گرفته می‌شود و سپس میانگین این مقدارها روی بازی‌هایی که انجام داده‌ای، امتیاز کلی است.",
                color = ReactColors.TextSecondary,
                style = MaterialTheme.typography.bodySmall,
            )
        }

        SectionTitle("آزمون‌ها")
        GameType.entries.forEach { type ->
            GameCard(type, onClick = { onGame(type) })
            Spacer(Modifier.height(12.dp))
        }

        SectionTitle("آخرین فعالیت‌ها")
        if (state.recent.isEmpty()) {
            NeonCard(Modifier.fillMaxWidth()) { CenterMessage("هنوز آزمونی انجام نداده‌ای. اولین آزمون را شروع کن!") }
        } else {
            state.recent.forEach { HistoryRow(it); Spacer(Modifier.height(8.dp)) }
        }
        Spacer(Modifier.height(12.dp))
        GhostButton("مشاهده آمار کامل", onStats)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun IconBox(icon: UiIcon, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(ReactColors.Card).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { UiIconImage(icon) }
}

@Composable
private fun GameCard(type: GameType, onClick: () -> Unit) {
    val accent = type.accent()
    NeonCard(Modifier.fillMaxWidth(), accent = accent, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(accent.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) { GameIcon(type, iconSize = 34.dp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(type.title, color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Text(type.shortDescription, color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
            UiIconImage(UiIcon.FORWARD, tint = accent)
        }
    }
}

@Composable
private fun HistoryRow(r: ResultRecord) {
    val accent = r.gameType.accent()
    NeonCard(Modifier.fillMaxWidth(), contentPadding = 12.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GameIcon(r.gameType, iconSize = 28.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.gameType.title, color = ReactColors.TextPrimary, style = MaterialTheme.typography.bodyMedium)
                Text(r.summaryText(), color = accent, style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(PersianFormat.date(r.createdAt), color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                Text(PersianFormat.time(r.createdAt), color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ───────────────────────────── آمار ─────────────────────────────

@Composable
fun StatsScreen(vm: StatsViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val s = state.summary

    ScreenScaffold("آمار و عملکرد", onBack) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip("همه", state.filter == null, ReactColors.Green) { vm.setFilter(null) }
            GameType.entries.forEach { FilterChip(it.title, state.filter == it, it.accent()) { vm.setFilter(it) } }
        }

        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("بهترین زمان واکنش", s.bestReactionMs?.let { msText(it) } ?: "—", Modifier.weight(1f))
            StatTile("میانگین زمان واکنش", s.averageReactionMs?.let { msText(it) } ?: "—", Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("بهترین رکورد حافظه", if (s.bestMemoryRounds > 0) "مرحله ${s.bestMemoryRounds.fa()}" else "—", Modifier.weight(1f), ReactColors.AccentMemory)
            StatTile("بالاترین امتیاز تمرکز", if (s.bestFocusScore > 0) s.bestFocusScore.fa() else "—", Modifier.weight(1f), ReactColors.AccentFocus)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("درصد دقت", s.accuracyPercent?.let { percentText(it) } ?: "—", Modifier.weight(1f), ReactColors.AccentAim)
            StatTile("امتیاز عملکرد کلی", s.overallPerformance.fa(), Modifier.weight(1f), ReactColors.AccentStroop)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("کل آزمون‌ها", s.totalTests.fa(), Modifier.weight(1f))
            StatTile("آزمون‌های موفق", s.successfulTests.fa(), Modifier.weight(1f))
        }

        SectionTitle("نمودار تغییرات عملکرد")
        NeonCard(Modifier.fillMaxWidth()) {
            if (state.trend.size < 2) {
                CenterMessage("برای رسم نمودار حداقل دو آزمون لازم است.")
            } else {
                Text("عملکرد ${state.trend.size.fa()} آزمون اخیر (از قدیم به جدید)", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                LineChart(state.trend, color = state.filter?.accent() ?: ReactColors.Green)
            }
        }

        SectionTitle("تاریخچه آزمون‌ها")
        if (state.history.isEmpty()) {
            NeonCard(Modifier.fillMaxWidth()) { CenterMessage("تاریخچه‌ای برای نمایش وجود ندارد.") }
        } else {
            state.history.take(100).forEach { HistoryRow(it); Spacer(Modifier.height(8.dp)) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FilterChip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) accent.copy(alpha = 0.18f) else ReactColors.Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
    ) {
        Text(text, color = if (selected) accent else ReactColors.TextSecondary, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
    }
}
