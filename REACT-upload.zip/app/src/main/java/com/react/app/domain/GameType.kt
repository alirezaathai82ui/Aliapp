package com.react.app.domain

/** پنج آزمون اصلی برنامه. نام enum در دیتابیس ذخیره می‌شود؛ تغییر آن نیاز به Migration دارد. */
enum class GameType(val title: String, val shortDescription: String) {
    REACTION("تست سرعت واکنش", "با دیدن رنگ سبز، سریع‌تر از همیشه لمس کن"),
    MEMORY("تست حافظه", "ترتیب خانه‌های روشن‌شده را تکرار کن"),
    FOCUS("تست تمرکز", "شکل هدف را میان شکل‌های مشابه پیدا کن"),
    AIM("تست دقت", "اهداف متحرک را بزن و لمس اشتباه نداشته باش"),
    STROOP("چالش رنگ‌ها", "رنگ واقعی نوشته را تشخیص بده، نه معنی کلمه را");

    companion object {
        fun fromKey(key: String): GameType? = entries.firstOrNull { it.name == key }
    }
}

/** پالت مشترک بازی‌های تمرکز و چالش رنگ‌ها. کد رنگ‌ها در لایه UI تعریف می‌شود. */
enum class GameColor(val fa: String) {
    RED("قرمز"),
    GREEN("سبز"),
    BLUE("آبی"),
    YELLOW("زرد"),
    ORANGE("نارنجی"),
    PURPLE("بنفش"),
}

enum class ShapeKind(val fa: String) {
    CIRCLE("دایره"),
    SQUARE("مربع"),
    TRIANGLE("مثلث"),
    DIAMOND("لوزی"),
    STAR("ستاره"),
    HEXAGON("شش‌ضلعی"),
}
