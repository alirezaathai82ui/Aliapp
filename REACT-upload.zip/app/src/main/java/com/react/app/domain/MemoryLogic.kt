package com.react.app.domain

import kotlin.random.Random

data class Cell(val row: Int, val col: Int)

object MemoryLogic {
    /** اندازه شبکه با بالا رفتن مرحله بزرگ‌تر می‌شود. چون خانه‌ها (سطر، ستون) هستند، دنباله قبلی معتبر می‌ماند. */
    fun gridSizeFor(round: Int): Int = when {
        round <= 5 -> 3
        round <= 12 -> 4
        else -> 5
    }

    fun flashDurationMs(round: Int): Long = (600L - round * 20L).coerceAtLeast(260L)

    fun gapMs(round: Int): Long = (250L - round * 8L).coerceAtLeast(120L)

    fun score(completedRounds: Int): Int = completedRounds * 10

    /** ۱۰ مرحله کامل = ۱۰۰٪ عملکرد. */
    fun performance(completedRounds: Int): Int = Scoring.clampPercent(completedRounds * 10)
}

sealed interface MemoryTap {
    data object Ignored : MemoryTap
    data object Correct : MemoryTap
    data object Wrong : MemoryTap
    data class RoundComplete(val completedRounds: Int) : MemoryTap
}

class MemorySession(private val random: Random = Random.Default) {
    var round: Int = 0
        private set
    var sequence: List<Cell> = emptyList()
        private set
    var inputIndex: Int = 0
        private set
    var completedRounds: Int = 0
        private set
    var totalTaps: Int = 0
        private set
    var correctTaps: Int = 0
        private set
    var isOver: Boolean = false
        private set

    val gridSize: Int get() = MemoryLogic.gridSizeFor(maxOf(round, 1))

    val accuracyPercent: Int
        get() = if (totalTaps == 0) 0 else correctTaps * 100 / totalTaps

    /** مرحله بعد: یک حرکت به دنباله اضافه می‌شود و کل دنباله برای نمایش برگردانده می‌شود. */
    fun startNextRound(): List<Cell> {
        check(!isOver) { "بازی تمام شده است" }
        round++
        val size = MemoryLogic.gridSizeFor(round)
        sequence = sequence + Cell(random.nextInt(size), random.nextInt(size))
        inputIndex = 0
        return sequence
    }

    fun tap(cell: Cell): MemoryTap {
        if (isOver || sequence.isEmpty()) return MemoryTap.Ignored
        totalTaps++
        if (sequence[inputIndex] != cell) {
            isOver = true
            return MemoryTap.Wrong
        }
        correctTaps++
        inputIndex++
        return if (inputIndex == sequence.size) {
            completedRounds++
            MemoryTap.RoundComplete(completedRounds)
        } else {
            MemoryTap.Correct
        }
    }
}
