package com.react.app.ui

import com.react.app.domain.GameType
import com.react.app.domain.ResultRecord
import com.react.app.util.PersianFormat

fun Int.fa(): String = PersianFormat.digits(this)

fun Long.fa(): String = PersianFormat.digits(this)

fun String.fa(): String = PersianFormat.digits(this)

fun msText(ms: Int): String = "${ms.fa()} میلی‌ثانیه"

fun percentText(percent: Int): String = "${percent.fa()}٪"

/** خلاصه یک‌خطی نتیجه برای فهرست تاریخچه. */
fun ResultRecord.summaryText(): String = when (gameType) {
    GameType.REACTION -> "میانگین ${msText(mainValue)}"
    GameType.MEMORY -> "مرحله ${mainValue.fa()}"
    GameType.FOCUS, GameType.AIM, GameType.STROOP ->
        "امتیاز ${score.fa()}" + if (accuracy >= 0) " · دقت ${percentText(accuracy)}" else ""
}
