package com.react.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.react.app.domain.Cell
import com.react.app.domain.GameType
import com.react.app.domain.ReactionLogic
import com.react.app.ui.components.NeonCard
import com.react.app.ui.components.OnStopEffect
import com.react.app.ui.components.ScreenScaffold
import com.react.app.ui.fa
import com.react.app.ui.msText
import com.react.app.ui.percentText
import com.react.app.ui.theme.ReactColors
import com.react.app.ui.theme.accent
import com.react.app.ui.viewmodel.MemoryPhase
import com.react.app.ui.viewmodel.MemoryViewModel
import com.react.app.ui.viewmodel.ReactionPhase
import com.react.app.ui.viewmodel.ReactionViewModel

private val WaitingColor = Color(0xFF3A1414)

@Composable
fun ReactionScreen(vm: ReactionViewModel, onBack: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val outcome by vm.outcome.collectAsState()
    OnStopEffect { vm.onLeave() }

    when (ui.phase) {
        ReactionPhase.INTRO -> ScreenScaffold(GameType.REACTION.title, onBack) {
            GameIntro(
                GameType.REACTION,
                listOf(
                    "با زدن «شروع»، صفحه قرمز می‌شود؛ صبر کن.",
                    "بعد از ۲ تا ۵ ثانیه رنگ صفحه سبز می‌شود.",
                    "به‌محض سبز شدن، هرجای صفحه را لمس کن.",
                    "لمس قبل از سبز شدن «شروع زودهنگام» است و دور تکرار می‌شود.",
                    "آزمون پنج دور دارد؛ میانگین، بهترین و بدترین زمان محاسبه می‌شود.",
                ),
                onStart = vm::start,
            )
        }

        ReactionPhase.FINISHED -> ScreenScaffold(GameType.REACTION.title, onBack) {
            val s = ui.summary
            if (s != null) {
                ResultPanel(
                    type = GameType.REACTION,
                    performance = s.performance,
                    success = s.success,
                    lines = listOf(
                        "میانگین" to msText(s.average),
                        "بهترین" to msText(s.best),
                        "بدترین" to msText(s.worst),
                        "شروع زودهنگام" to s.falseStarts.fa(),
                    ),
                    outcome = outcome,
                    onRetry = vm::start,
                    onHome = onBack,
                )
            }
        }

        else -> {
            val (bg, title, subtitle) = when (ui.phase) {
                ReactionPhase.WAITING -> Triple(WaitingColor, "صبر کن…", "تا سبز شدن صفحه لمس نکن")
                ReactionPhase.GO -> Triple(ReactColors.Green, "لمس کن!", "")
                ReactionPhase.RESULT -> Triple(ReactColors.Card, msText(ui.lastMs ?: 0), "آماده دور بعد…")
                else -> Triple(ReactColors.Warning, "زود بود!", "شروع زودهنگام ثبت شد؛ دور تکرار می‌شود")
            }
            val textColor = if (ui.phase == ReactionPhase.GO || ui.phase == ReactionPhase.FALSE_START) ReactColors.Background else ReactColors.TextPrimary
            Box(
                Modifier
                    .fillMaxSize()
                    .background(bg)
                    // لمس روی «لحظه فشردن» ثبت می‌شود، نه رها کردن، تا زمان واکنش دقیق باشد.
                    .pointerInput(Unit) { detectTapGestures(onPress = { vm.onTouch() }) },
                contentAlignment = Alignment.Center,
            ) {
                Column(Modifier.statusBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "دور ${(ui.completedRounds + 1).coerceAtMost(ReactionLogic.ROUNDS).fa()} از ${ReactionLogic.ROUNDS.fa()}",
                        color = textColor.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(title, color = textColor, fontSize = 40.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    if (subtitle.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text(subtitle, color = textColor.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryScreen(vm: MemoryViewModel, onBack: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val outcome by vm.outcome.collectAsState()
    val accent = GameType.MEMORY.accent()
    OnStopEffect { vm.onLeave() }

    ScreenScaffold(GameType.MEMORY.title, onBack, scroll = ui.phase == MemoryPhase.INTRO || ui.phase == MemoryPhase.OVER) {
        when (ui.phase) {
            MemoryPhase.INTRO -> GameIntro(
                GameType.MEMORY,
                listOf(
                    "چند خانه به‌ترتیب روشن می‌شوند؛ دقت کن.",
                    "بعد همان ترتیب را لمس کن.",
                    "در هر مرحله یک حرکت به دنباله اضافه می‌شود.",
                    "با رسیدن به مراحل بالاتر شبکه بزرگ‌تر می‌شود.",
                    "یک انتخاب اشتباه بازی را تمام می‌کند. بالاترین مرحله ذخیره می‌شود.",
                ),
                onStart = vm::start,
            )

            MemoryPhase.OVER -> {
                val completed = ui.completedRounds
                val performance = com.react.app.domain.MemoryLogic.performance(completed)
                ResultPanel(
                    type = GameType.MEMORY,
                    performance = performance,
                    success = com.react.app.domain.Scoring.isSuccess(performance),
                    lines = listOf(
                        "مراحل کامل‌شده" to completed.fa(),
                        "امتیاز" to com.react.app.domain.MemoryLogic.score(completed).fa(),
                    ),
                    outcome = outcome,
                    onRetry = vm::start,
                    onHome = onBack,
                )
            }

            else -> {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("مرحله ${ui.round.fa()}", color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (ui.phase == MemoryPhase.SHOWING) "ترتیب را به خاطر بسپار" else "نوبت توست",
                        color = accent,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                Spacer(Modifier.height(24.dp))
                MemoryGrid(
                    size = ui.gridSize,
                    lit = ui.lit,
                    pressed = ui.pressed,
                    accent = accent,
                    enabled = ui.phase == MemoryPhase.INPUT,
                    onTap = vm::tap,
                )
            }
        }
    }
}

@Composable
private fun MemoryGrid(size: Int, lit: Cell?, pressed: Cell?, accent: Color, enabled: Boolean, onTap: (Cell) -> Unit) {
    val gap = 10.dp
    Column(Modifier.fillMaxWidth().aspectRatio(1f), verticalArrangement = Arrangement.spacedBy(gap)) {
        for (r in 0 until size) {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                for (c in 0 until size) {
                    val cell = Cell(r, c)
                    val active = cell == lit || cell == pressed
                    val shape = RoundedCornerShape(16.dp)
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .then(if (active) Modifier.shadow(16.dp, shape, ambientColor = accent, spotColor = accent) else Modifier)
                            .clip(shape)
                            .background(if (active) accent else ReactColors.CardHigh)
                            .border(1.dp, if (active) accent else ReactColors.Outline, shape)
                            .clickable(enabled = enabled) { onTap(cell) },
                    )
                }
            }
        }
    }
}
