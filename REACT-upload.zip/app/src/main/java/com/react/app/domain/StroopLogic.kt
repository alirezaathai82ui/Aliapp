package com.react.app.domain

import kotlin.math.roundToInt
import kotlin.random.Random

/** [word] نام یک رنگ است که با رنگ [ink] نمایش داده می‌شود؛ پاسخ درست همیشه [ink] است. */
data class StroopQuestion(
    val index: Int,
    val word: GameColor,
    val ink: GameColor,
    val options: List<GameColor>,
    val timeLimitMs: Long,
)

object StroopLogic {
    const val QUESTIONS = 20
    const val CORRECT_BASE = 10
    const val WRONG_PENALTY = 5

    /** تعداد رنگ‌های موجود با پیشرفت زیاد می‌شود (index از صفر). */
    fun paletteSize(index: Int): Int = when {
        index < 7 -> 4
        index < 14 -> 5
        else -> 6
    }

    fun timeLimitMs(index: Int): Long = (3_500L - 120L * index).coerceAtLeast(1_200L)

    fun correctPoints(remainingMs: Long, limitMs: Long): Int {
        val fraction = (remainingMs.toDouble() / limitMs).coerceIn(0.0, 1.0)
        return CORRECT_BASE + (5.0 * fraction).roundToInt()
    }

    fun generate(index: Int, random: Random): StroopQuestion {
        val palette = GameColor.entries.take(paletteSize(index))
        val ink = palette.random(random)
        val word = palette.filter { it != ink }.random(random)
        return StroopQuestion(index, word, ink, palette.shuffled(random), timeLimitMs(index))
    }
}

sealed interface StroopAnswer {
    data class Correct(val points: Int) : StroopAnswer
    data object Wrong : StroopAnswer
    data object Ignored : StroopAnswer
}

class StroopSession(private val random: Random = Random.Default) {
    var asked: Int = 0
        private set
    var score: Int = 0
        private set
    var correct: Int = 0
        private set
    var wrong: Int = 0
        private set
    var current: StroopQuestion? = null
        private set

    private var correctTimeSum = 0L

    /** میانگین زمان پاسخ‌های درست (میلی‌ثانیه)؛ بدون پاسخ درست ۰. */
    val averageCorrectTimeMs: Int
        get() = if (correct == 0) 0 else (correctTimeSum / correct).toInt()

    val isFinished: Boolean get() = asked >= StroopLogic.QUESTIONS && current == null

    val accuracyPercent: Int get() = correct * 100 / StroopLogic.QUESTIONS

    val performance: Int get() = Scoring.normalize(score, Scoring.STROOP_REFERENCE_SCORE)

    fun next(): StroopQuestion? {
        if (current != null || asked >= StroopLogic.QUESTIONS) return null
        val question = StroopLogic.generate(asked, random)
        asked++
        current = question
        return question
    }

    fun answer(chosen: GameColor, remainingMs: Long): StroopAnswer {
        val q = current ?: return StroopAnswer.Ignored
        current = null
        return if (chosen == q.ink) {
            val points = StroopLogic.correctPoints(remainingMs, q.timeLimitMs)
            correctTimeSum += (q.timeLimitMs - remainingMs).coerceIn(0L, q.timeLimitMs)
            correct++
            score += points
            StroopAnswer.Correct(points)
        } else {
            registerWrong()
            StroopAnswer.Wrong
        }
    }

    /** نرسیدن به پاسخ در مهلت، پاسخ اشتباه محسوب می‌شود. */
    fun timeout() {
        if (current == null) return
        current = null
        registerWrong()
    }

    private fun registerWrong() {
        wrong++
        score = (score - StroopLogic.WRONG_PENALTY).coerceAtLeast(0)
    }
}
