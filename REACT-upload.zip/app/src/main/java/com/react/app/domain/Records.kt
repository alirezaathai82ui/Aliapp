package com.react.app.domain

/** پروفایل محلی کاربر. شمارنده‌ها با پاک شدن تاریخچه صفر نمی‌شوند. */
data class Profile(
    val name: String = DEFAULT_NAME,
    val avatar: Int = 0,
    val xp: Int = 0,
    val totalTests: Int = 0,
    val successfulTests: Int = 0,
    val successStreak: Int = 0,
) {
    val level: RankLevel get() = LevelSystem.levelFor(xp)

    companion object {
        const val DEFAULT_NAME = "بازیکن"
        const val MAX_NAME_LENGTH = 16
        const val AVATAR_COUNT = 8

        fun sanitizeName(raw: String): String =
            raw.trim().replace(Regex("\\s+"), " ").take(MAX_NAME_LENGTH).ifBlank { DEFAULT_NAME }
    }
}

/** نتیجه یک آزمون که تازه تمام شده و هنوز ذخیره نشده است. */
data class NewResult(
    val gameType: GameType,
    val score: Int,
    val performance: Int,
    val success: Boolean,
    /** درصد دقت؛ ۱- یعنی برای این بازی تعریف نشده. */
    val accuracy: Int,
    /** واکنش: میانگین ms، حافظه: مراحل کامل، بقیه: امتیاز. */
    val mainValue: Int,
    /** واکنش: سریع‌ترین دور (ms)، تمرکز و چالش رنگ: میانگین زمان پاسخ درست (ms)، بقیه ۰. */
    val bestValue: Int,
)

/**
 * بهترین‌های شخصی هر بازی (جدا از تاریخچه ذخیره می‌شوند تا با پاک کردن تاریخچه از بین نروند).
 * واکنش: bestMain = کمترین میانگین، bestSecondary = سریع‌ترین دور؛ در بقیه بازی‌ها bestMain بیشینه است.
 */
data class RecordSnapshot(
    val gameType: GameType,
    val bestMain: Int,
    val bestSecondary: Int,
    val bestScore: Int,
    val bestAccuracy: Int,
)

object RecordRules {
    fun merge(old: RecordSnapshot?, r: NewResult): RecordSnapshot {
        val accuracy = maxOf(old?.bestAccuracy ?: 0, r.accuracy.coerceAtLeast(0))
        val score = maxOf(old?.bestScore ?: 0, r.score)
        return if (r.gameType == GameType.REACTION) {
            RecordSnapshot(
                gameType = r.gameType,
                bestMain = lowestPositive(old?.bestMain ?: 0, r.mainValue),
                bestSecondary = lowestPositive(old?.bestSecondary ?: 0, r.bestValue),
                bestScore = score,
                bestAccuracy = accuracy,
            )
        } else {
            RecordSnapshot(
                gameType = r.gameType,
                bestMain = maxOf(old?.bestMain ?: 0, r.mainValue),
                bestSecondary = 0,
                bestScore = score,
                bestAccuracy = accuracy,
            )
        }
    }

    private fun lowestPositive(a: Int, b: Int): Int = when {
        a <= 0 -> b.coerceAtLeast(0)
        b <= 0 -> a
        else -> minOf(a, b)
    }
}

/** ساخت [NewResult] از وضعیت پایانی هر بازی. */
object ResultFactory {
    fun reaction(s: ReactionSummary) = NewResult(
        GameType.REACTION, s.performance, s.performance, s.success, -1, s.average, s.best,
    )

    fun memory(s: MemorySession): NewResult {
        val performance = MemoryLogic.performance(s.completedRounds)
        return NewResult(
            GameType.MEMORY, MemoryLogic.score(s.completedRounds), performance,
            Scoring.isSuccess(performance), s.accuracyPercent, s.completedRounds, 0,
        )
    }

    fun focus(s: FocusSession) = NewResult(
        GameType.FOCUS, s.score, s.performance, Scoring.isSuccess(s.performance),
        s.accuracyPercent, s.score, s.averageCorrectTimeMs,
    )

    fun aim(e: AimEngine) = NewResult(
        GameType.AIM, e.score, e.performance, Scoring.isSuccess(e.performance),
        e.accuracyPercent, e.score, 0,
    )

    fun stroop(s: StroopSession) = NewResult(
        GameType.STROOP, s.score, s.performance, Scoring.isSuccess(s.performance),
        s.accuracyPercent, s.score, s.averageCorrectTimeMs,
    )
}

/** نتیجه ثبت یک آزمون که روی صفحه نتیجه نمایش داده می‌شود. */
data class RecordOutcome(
    val xpGained: Int,
    val totalXp: Int,
    val previousLevel: RankLevel,
    val newLevel: RankLevel,
    val newAchievements: List<Achievement>,
    val brokeRecord: Boolean,
) {
    val leveledUp: Boolean get() = newLevel.ordinal > previousLevel.ordinal
}
