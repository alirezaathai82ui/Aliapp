package com.react.app

import android.app.Application
import android.content.Context
import com.react.app.data.db.ReactDatabase
import com.react.app.data.prefs.SettingsStore
import com.react.app.data.repo.ReactRepository
import com.react.app.feedback.Feedback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** تزریق وابستگی دستی؛ برای اپ کوچکی مثل REACT ساده‌تر و شفاف‌تر از Hilt است. */
class AppContainer(context: Context, scope: CoroutineScope) {
    private val appContext = context.applicationContext

    val settings = SettingsStore(appContext)
    val database: ReactDatabase by lazy { ReactDatabase.create(appContext) }
    val repository: ReactRepository by lazy { ReactRepository(database, settings) }
    val feedback = Feedback(appContext, settings.settings, scope)
}

class ReactApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this, appScope)
    }
}
