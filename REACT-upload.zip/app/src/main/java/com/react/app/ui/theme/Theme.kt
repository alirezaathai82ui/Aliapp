package com.react.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.compose.material3.LocalContentColor
import androidx.compose.ui.platform.LocalLayoutDirection
import com.react.app.domain.GameColor
import com.react.app.domain.GameType

/** پالت برند REACT (مشکی و سبز نئونی). */
object ReactColors {
    val Background = Color(0xFF080B0A)
    val Card = Color(0xFF111714)
    val CardHigh = Color(0xFF17201B)
    val Green = Color(0xFF39FF88)
    val GreenDark = Color(0xFF19C96B)
    val TextPrimary = Color(0xFFF5F7F5)
    val TextSecondary = Color(0xFF929B95)
    val Warning = Color(0xFFFF4545)
    val Outline = Color(0xFF1F2B24)

    val AccentReaction = Green
    val AccentMemory = Color(0xFF4DD6FF)
    val AccentFocus = Color(0xFFFFD93D)
    val AccentAim = Color(0xFFFF9A3D)
    val AccentStroop = Color(0xFFB46BFF)
}

fun GameType.accent(): Color = when (this) {
    GameType.REACTION -> ReactColors.AccentReaction
    GameType.MEMORY -> ReactColors.AccentMemory
    GameType.FOCUS -> ReactColors.AccentFocus
    GameType.AIM -> ReactColors.AccentAim
    GameType.STROOP -> ReactColors.AccentStroop
}

/** رنگ واقعی هر عضو پالت بازی‌های تمرکز و چالش رنگ‌ها. */
fun GameColor.toColor(): Color = when (this) {
    GameColor.RED -> Color(0xFFFF4545)
    GameColor.GREEN -> Color(0xFF39FF88)
    GameColor.BLUE -> Color(0xFF3DA5FF)
    GameColor.YELLOW -> Color(0xFFFFD93D)
    GameColor.ORANGE -> Color(0xFFFF9A3D)
    GameColor.PURPLE -> Color(0xFFB46BFF)
}

private val ReactColorScheme = darkColorScheme(
    primary = ReactColors.Green,
    onPrimary = ReactColors.Background,
    secondary = ReactColors.GreenDark,
    onSecondary = ReactColors.Background,
    background = ReactColors.Background,
    onBackground = ReactColors.TextPrimary,
    surface = ReactColors.Card,
    onSurface = ReactColors.TextPrimary,
    surfaceVariant = ReactColors.CardHigh,
    onSurfaceVariant = ReactColors.TextSecondary,
    error = ReactColors.Warning,
    outline = ReactColors.Outline,
)

/**
 * اگر فایل‌های فونت فارسی (مثلاً Vazirmatn با مجوز OFL) با نام‌های
 * `vazirmatn_regular.ttf` و `vazirmatn_bold.ttf` در `res/font` گذاشته شوند، بدون تغییر کد استفاده می‌شوند؛
 * در غیر این صورت فونت پیش‌فرض سیستم (که فارسی را پشتیبانی می‌کند) به کار می‌رود.
 */
@Composable
private fun rememberReactFontFamily(): FontFamily {
    val context = LocalContext.current
    return remember(context) {
        val regular = context.resources.getIdentifier("vazirmatn_regular", "font", context.packageName)
        val bold = context.resources.getIdentifier("vazirmatn_bold", "font", context.packageName)
        if (regular != 0) {
            FontFamily(
                Font(regular, FontWeight.Normal),
                Font(if (bold != 0) bold else regular, FontWeight.Bold),
            )
        } else {
            FontFamily.Default
        }
    }
}

private fun reactTypography(family: FontFamily) = Typography(
    displayMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 44.sp, lineHeight = 54.sp),
    headlineMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 38.sp),
    headlineSmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 24.sp),
    bodyLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 26.sp),
    bodyMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 22.sp),
    bodySmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 15.sp, lineHeight = 22.sp),
    labelMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 11.sp, lineHeight = 14.sp),
)

/** تم همیشه تیره و راست‌به‌چپ (فقط فارسی). */
@Composable
fun ReactTheme(content: @Composable () -> Unit) {
    val family = rememberReactFontFamily()
    val typography = remember(family) { reactTypography(family) }
    MaterialTheme(colorScheme = ReactColorScheme, typography = typography) {
        CompositionLocalProvider(
            LocalLayoutDirection provides LayoutDirection.Rtl,
            LocalContentColor provides ReactColors.TextPrimary,
        ) {
            content()
        }
    }
}
