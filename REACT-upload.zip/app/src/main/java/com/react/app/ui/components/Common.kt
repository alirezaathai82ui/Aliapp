package com.react.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.react.app.ui.theme.ReactColors

val CardShape = RoundedCornerShape(20.dp)
val ButtonShape = RoundedCornerShape(16.dp)

/** پس‌زمینه تیره + نوار بالا با دکمه بازگشت. */
@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    scroll: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxSize()
            .background(ReactColors.Background)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (onBack != null) {
                Box(
                    Modifier.size(44.dp).clip(ButtonShape).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) { UiIconImage(UiIcon.BACK) }
            } else {
                Spacer(Modifier.width(12.dp))
            }
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                color = ReactColors.TextPrimary,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
            )
            actions()
        }
        val bodyModifier = Modifier.weight(1f).fillMaxWidth().let {
            if (scroll) it.verticalScroll(rememberScrollState()) else it
        }
        Column(bodyModifier.padding(horizontal = 20.dp), content = content)
    }
}

@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    accent: Color? = null,
    onClick: (() -> Unit)? = null,
    contentPadding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val border = accent?.copy(alpha = 0.35f) ?: ReactColors.Outline
    val brush = if (accent != null) {
        Brush.linearGradient(listOf(accent.copy(alpha = 0.10f), ReactColors.Card))
    } else {
        Brush.linearGradient(listOf(ReactColors.Card, ReactColors.Card))
    }
    Column(
        modifier
            .clip(CardShape)
            .background(brush)
            .border(1.dp, border, CardShape)
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(contentPadding),
        content = content,
    )
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val glow = if (enabled) ReactColors.Green else Color.Transparent
    Box(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .shadow(14.dp, ButtonShape, ambientColor = glow, spotColor = glow)
            .clip(ButtonShape)
            .background(
                if (enabled) Brush.horizontalGradient(listOf(ReactColors.Green, ReactColors.GreenDark))
                else Brush.horizontalGradient(listOf(ReactColors.CardHigh, ReactColors.CardHigh)),
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            color = if (enabled) ReactColors.Background else ReactColors.TextSecondary,
        )
    }
}

@Composable
fun GhostButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = ReactColors.Green,
) {
    Box(
        modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(ButtonShape)
            .border(1.dp, color.copy(alpha = 0.6f), ButtonShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = color)
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier, accent: Color = ReactColors.Green) {
    NeonCard(modifier, contentPadding = 14.dp) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = ReactColors.TextSecondary)
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleLarge, color = accent, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun NeonProgressBar(progress: Float, modifier: Modifier = Modifier, color: Color = ReactColors.Green) {
    val shape = RoundedCornerShape(50)
    Box(modifier.fillMaxWidth().height(8.dp).clip(shape).background(ReactColors.CardHigh)) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .height(8.dp)
                .clip(shape)
                .background(Brush.horizontalGradient(listOf(color, ReactColors.GreenDark))),
        )
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = ReactColors.TextPrimary,
        modifier = modifier.padding(top = 20.dp, bottom = 10.dp),
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    dangerous: Boolean = true,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ReactColors.Card,
        titleContentColor = ReactColors.TextPrimary,
        textContentColor = ReactColors.TextSecondary,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(confirmText, color = if (dangerous) ReactColors.Warning else ReactColors.Green)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف", color = ReactColors.TextSecondary) }
        },
    )
}

/** نمودار خطی ساده؛ [values] درصد (۰..۱۰۰) به ترتیب زمانی است. نمودار فقط از داده واقعی ساخته می‌شود. */
@Composable
fun LineChart(values: List<Int>, modifier: Modifier = Modifier, color: Color = ReactColors.Green) {
    Canvas(modifier.fillMaxWidth().height(150.dp)) {
        val w = size.width
        val h = size.height
        val pad = 8.dp.toPx()
        for (i in 0..4) {
            val y = pad + (h - 2 * pad) * i / 4f
            drawLine(ReactColors.Outline, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }
        if (values.isEmpty()) return@Canvas
        fun point(i: Int): Offset {
            val x = if (values.size == 1) w / 2f else pad + (w - 2 * pad) * i / (values.size - 1)
            val y = pad + (h - 2 * pad) * (1f - values[i].coerceIn(0, 100) / 100f)
            return Offset(x, y)
        }
        if (values.size > 1) {
            val line = Path().apply {
                values.indices.forEach { i -> point(i).let { if (i == 0) moveTo(it.x, it.y) else lineTo(it.x, it.y) } }
            }
            val area = Path().apply {
                addPath(line)
                lineTo(point(values.lastIndex).x, h - pad)
                lineTo(point(0).x, h - pad)
                close()
            }
            drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = 0.28f), Color.Transparent)))
            drawPath(line, color, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        values.indices.forEach { i ->
            drawCircle(ReactColors.Background, 5.dp.toPx(), point(i))
            drawCircle(color, 3.5.dp.toPx(), point(i))
        }
    }
}

@Composable
fun CenterMessage(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = ReactColors.TextSecondary, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
    }
}

/** هر بار که برنامه به پس‌زمینه می‌رود یا صفحه متوقف می‌شود، [action] صدا زده می‌شود (برای توقف بازی‌های زمان‌دار). */
@Composable
fun OnStopEffect(action: () -> Unit) {
    val current by rememberUpdatedState(action)
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_STOP) current() }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
}

@Composable
fun Dot(color: Color, modifier: Modifier = Modifier, dotSize: Dp = 8.dp) {
    Box(modifier.size(dotSize).clip(RoundedCornerShape(50)).background(color))
}
