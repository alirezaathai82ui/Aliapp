package com.react.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.react.app.domain.GameType
import com.react.app.domain.RecordOutcome
import com.react.app.ui.components.GameIcon
import com.react.app.ui.components.GhostButton
import com.react.app.ui.components.NeonButton
import com.react.app.ui.components.NeonCard
import com.react.app.ui.components.NeonProgressBar
import com.react.app.ui.fa
import com.react.app.ui.theme.ReactColors
import com.react.app.ui.theme.accent

/** صفحه معرفی هر آزمون: آیکن، توضیح، قواعد و دکمه شروع. */
@Composable
fun ColumnScope.GameIntro(type: GameType, rules: List<String>, onStart: () -> Unit) {
    val accent = type.accent()
    Spacer(Modifier.height(12.dp))
    NeonCard(Modifier.fillMaxWidth(), accent = accent, contentPadding = 20.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GameIcon(type, iconSize = 44.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(type.title, style = MaterialTheme.typography.titleLarge, color = ReactColors.TextPrimary)
                Text(type.shortDescription, style = MaterialTheme.typography.bodyMedium, color = ReactColors.TextSecondary)
            }
        }
    }
    Spacer(Modifier.height(16.dp))
    NeonCard(Modifier.fillMaxWidth()) {
        Text("قوانین", style = MaterialTheme.typography.titleMedium, color = accent)
        Spacer(Modifier.height(8.dp))
        rules.forEachIndexed { i, rule ->
            Row(Modifier.padding(vertical = 4.dp)) {
                Text("${(i + 1).fa()}.", color = accent, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.width(8.dp))
                Text(rule, color = ReactColors.TextPrimary, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
    Spacer(Modifier.height(24.dp))
    NeonButton("شروع آزمون", onStart)
    Spacer(Modifier.height(20.dp))
}

/** نتیجه نهایی: عملکرد، خطوط آمار، XP/سطح/دستاوردها و دکمه‌های ادامه. */
@Composable
fun ColumnScope.ResultPanel(
    type: GameType,
    performance: Int,
    success: Boolean,
    lines: List<Pair<String, String>>,
    outcome: RecordOutcome?,
    onRetry: () -> Unit,
    onHome: () -> Unit,
) {
    val accent = type.accent()
    val progress = remember { Animatable(0f) }
    LaunchedEffect(performance) { progress.animateTo(1f, tween(900)) }
    val shown = (performance * progress.value).toInt()

    Spacer(Modifier.height(12.dp))
    NeonCard(Modifier.fillMaxWidth(), accent = if (success) accent else ReactColors.Warning, contentPadding = 24.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (success) "آزمون موفق!" else "تلاش بیشتر لازم است",
                style = MaterialTheme.typography.titleMedium,
                color = if (success) accent else ReactColors.Warning,
            )
            Spacer(Modifier.height(8.dp))
            Text(shown.fa(), fontSize = 64.sp, fontWeight = FontWeight.Bold, color = ReactColors.TextPrimary)
            Text("امتیاز عملکرد از ۱۰۰", style = MaterialTheme.typography.bodySmall, color = ReactColors.TextSecondary)
            Spacer(Modifier.height(12.dp))
            NeonProgressBar(progress.value * performance / 100f, color = accent)
        }
    }
    Spacer(Modifier.height(12.dp))
    NeonCard(Modifier.fillMaxWidth()) {
        lines.forEachIndexed { i, (label, value) ->
            if (i > 0) Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                Text(value, color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    if (outcome == null) {
        Text("در حال ذخیره نتیجه…", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    } else {
        NeonCard(Modifier.fillMaxWidth(), accent = ReactColors.Green) {
            Text("+${outcome.xpGained.fa()} XP", color = ReactColors.Green, style = MaterialTheme.typography.titleLarge)
            if (outcome.brokeRecord) {
                Text("رکورد شخصی تازه ثبت شد 🔥", color = ReactColors.TextPrimary, style = MaterialTheme.typography.bodyMedium)
            }
            if (outcome.leveledUp) {
                Spacer(Modifier.height(6.dp))
                Text("ارتقا به سطح «${outcome.newLevel.title}»", color = ReactColors.Green, style = MaterialTheme.typography.titleMedium)
            }
            outcome.newAchievements.forEach {
                Spacer(Modifier.height(6.dp))
                Text("دستاورد جدید: ${it.title}", color = ReactColors.AccentFocus, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
    Spacer(Modifier.height(20.dp))
    NeonButton("تلاش دوباره", onRetry)
    Spacer(Modifier.height(10.dp))
    GhostButton("بازگشت به خانه", onHome)
    Spacer(Modifier.height(20.dp))
}

/** نوار بالای بازی در حال اجرا: چپ و راست دو مقدار، وسط عنوان کوتاه. */
@Composable
fun GameHud(left: String, center: String, right: String, accent: Color, progress: Float? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(left, color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
            Text(center, color = accent, style = MaterialTheme.typography.bodyMedium)
            Text(right, color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
        }
        if (progress != null) {
            Spacer(Modifier.height(8.dp))
            NeonProgressBar(progress, color = accent)
        }
    }
}
