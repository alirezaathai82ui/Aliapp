package com.react.app.domain

import kotlin.math.roundToInt
import kotlin.random.Random

object ReactionLogic {
    const val ROUNDS = 5
    const val MIN_DELAY_MS = 2_000L
    const val MAX_DELAY_MS = 5_000L

    /** لمس زودتر از این مقدار پس از سبز شدن از نظر فیزیولوژیک ممکن نیست و خطای پیش‌بینی حساب می‌شود. */
    const val MIN_PLAUSIBLE_MS = 80

    /** اگر کاربر تا این مدت پس از سبز شدن لمس نکند، دور با همین زمان ثبت می‌شود. */
    const val TIMEOUT_MS = 2_000

    private const val SLOWEST_MS = 700
    private const val SPAN_MS = 500
    private const val FALSE_START_PENALTY = 5

    fun randomDelayMs(random: Random): Long = random.nextLong(MIN_DELAY_MS, MAX_DELAY_MS + 1)

    /** اختلاف دو زمان از ساعت monotonic (نانوثانیه) بر حسب میلی‌ثانیه، با گرد کردن. */
    fun elapsedMs(startNanos: Long, endNanos: Long): Int =
        (((endNanos - startNanos) + 500_000L) / 1_000_000L).toInt()

    fun performance(averageMs: Int, falseStarts: Int): Int {
        if (averageMs <= 0) return 0
        val base = (SLOWEST_MS - averageMs) * 100 / SPAN_MS
        return Scoring.clampPercent(base - falseStarts * FALSE_START_PENALTY)
    }
}

data class ReactionSummary(val timesMs: List<Int>, val falseStarts: Int) {
    val average: Int
        get() = if (timesMs.isEmpty()) 0 else (timesMs.sum().toDouble() / timesMs.size).roundToInt()
    val best: Int get() = timesMs.minOrNull() ?: 0
    val worst: Int get() = timesMs.maxOrNull() ?: 0
    val performance: Int get() = ReactionLogic.performance(average, falseStarts)
    val success: Boolean
        get() = timesMs.size == ReactionLogic.ROUNDS && Scoring.isSuccess(performance)
}

sealed interface ReactionTouch {
    data object Ignored : ReactionTouch
    data object FalseStart : ReactionTouch
    data class Recorded(val ms: Int, val finished: Boolean) : ReactionTouch
}

/**
 * ماشین حالت یک آزمون واکنش. زمان‌ها از بیرون (ساعت monotonic) تزریق می‌شوند
 * تا منطق کاملاً قابل تست باشد.
 */
class ReactionSession(private val rounds: Int = ReactionLogic.ROUNDS) {
    enum class Phase { IDLE, WAITING, GO, SHOWING_RESULT, FALSE_START, FINISHED }

    var phase: Phase = Phase.IDLE
        private set
    var falseStarts: Int = 0
        private set
    private val times = mutableListOf<Int>()
    private var goAtNanos = 0L

    val completedRounds: Int get() = times.size
    val currentRound: Int get() = (times.size + 1).coerceAtMost(rounds)
    val lastTimeMs: Int? get() = times.lastOrNull()

    /** شروع انتظار برای دور بعد (از حالت IDLE، نتیجه دور قبل یا خطای شروع زودهنگام). */
    fun beginWaiting() {
        if (phase == Phase.IDLE || phase == Phase.SHOWING_RESULT || phase == Phase.FALSE_START) {
            phase = Phase.WAITING
        }
    }

    fun showGreen(nowNanos: Long) {
        if (phase == Phase.WAITING) {
            phase = Phase.GO
            goAtNanos = nowNanos
        }
    }

    fun touch(nowNanos: Long): ReactionTouch = when (phase) {
        Phase.WAITING -> registerFalseStart()
        Phase.GO -> {
            val ms = ReactionLogic.elapsedMs(goAtNanos, nowNanos)
            if (ms < ReactionLogic.MIN_PLAUSIBLE_MS) registerFalseStart() else record(ms)
        }
        else -> ReactionTouch.Ignored
    }

    /** فراخوانی وقتی مهلت لمس پس از سبز شدن تمام شد. */
    fun timeout(): ReactionTouch =
        if (phase == Phase.GO) record(ReactionLogic.TIMEOUT_MS) else ReactionTouch.Ignored

    fun summary(): ReactionSummary = ReactionSummary(times.toList(), falseStarts)

    private fun registerFalseStart(): ReactionTouch {
        falseStarts++
        phase = Phase.FALSE_START
        return ReactionTouch.FalseStart
    }

    private fun record(ms: Int): ReactionTouch {
        times += ms.coerceAtMost(ReactionLogic.TIMEOUT_MS)
        val finished = times.size >= rounds
        phase = if (finished) Phase.FINISHED else Phase.SHOWING_RESULT
        return ReactionTouch.Recorded(times.last(), finished)
    }
}
