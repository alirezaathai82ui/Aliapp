package com.react.app.domain

/** نسخه خالص (بدون Room) از یک نتیجه ذخیره‌شده. accuracy برابر ۱- یعنی «نامربوط». */
data class ResultRecord(
    val id: Long,
    val gameType: GameType,
    val score: Int,
    val performance: Int,
    val success: Boolean,
    val accuracy: Int,
    val mainValue: Int,
    val bestValue: Int,
    val xpGained: Int,
    val createdAt: Long,
)

data class StatsSummary(
    val bestReactionMs: Int?,
    val averageReactionMs: Int?,
    val bestMemoryRounds: Int,
    val bestFocusScore: Int,
    val accuracyPercent: Int?,
    val totalTests: Int,
    val successfulTests: Int,
    val overallPerformance: Int,
)

/** ورودی لیست‌ها همیشه «جدیدترین اول» است (همان ترتیب DAO). */
object StatsCalculator {
    /** تعداد آزمون اخیر هر بازی که در امتیاز کلی حساب می‌شود. */
    const val RECENT_WINDOW = 5

    /**
     * بهترین‌ها از [records] و شمارنده‌ها از پروفایل می‌آیند (با پاک شدن تاریخچه حفظ می‌شوند)؛
     * میانگین‌ها، دقت و امتیاز کلی از [results] (تاریخچه) محاسبه می‌شوند.
     */
    fun summarize(
        results: List<ResultRecord>,
        records: List<RecordSnapshot> = emptyList(),
        totalTests: Int = results.size,
        successfulTests: Int = results.count { it.success },
    ): StatsSummary {
        val reaction = results.filter { it.gameType == GameType.REACTION }
        val withAccuracy = results.filter { it.accuracy >= 0 }
        val record = { type: GameType -> records.firstOrNull { it.gameType == type } }
        return StatsSummary(
            bestReactionMs = record(GameType.REACTION)?.bestSecondary?.takeIf { it > 0 },
            averageReactionMs = reaction.map { it.mainValue }.filter { it > 0 }
                .takeIf { it.isNotEmpty() }?.average()?.let { Math.round(it).toInt() },
            bestMemoryRounds = record(GameType.MEMORY)?.bestMain ?: 0,
            bestFocusScore = record(GameType.FOCUS)?.bestScore ?: 0,
            accuracyPercent = withAccuracy.takeIf { it.isNotEmpty() }
                ?.map { it.accuracy }?.average()?.let { Math.round(it).toInt() },
            totalTests = totalTests,
            successfulTests = successfulTests,
            overallPerformance = overallPerformance(results),
        )
    }

    /**
     * امتیاز عملکرد کلی: برای هر بازی که حداقل یک‌بار انجام شده میانگین عملکرد ۵ آزمون اخیر
     * محاسبه می‌شود و سپس میانگین این میانگین‌ها (گردشده) امتیاز نهایی ۰ تا ۱۰۰ است.
     */
    fun overallPerformance(results: List<ResultRecord>): Int {
        val perGame = GameType.entries.mapNotNull { type ->
            results.filter { it.gameType == type }
                .take(RECENT_WINDOW)
                .map { it.performance }
                .takeIf { it.isNotEmpty() }
                ?.average()
        }
        return if (perGame.isEmpty()) 0 else Math.round(perGame.average()).toInt()
    }

    /** روند عملکرد به ترتیب زمانی (قدیمی به جدید)؛ حداکثر [limit] نتیجه آخر. */
    fun trend(results: List<ResultRecord>, type: GameType? = null, limit: Int = 20): List<Int> =
        results.filter { type == null || it.gameType == type }
            .take(limit)
            .map { it.performance }
            .reversed()
}
