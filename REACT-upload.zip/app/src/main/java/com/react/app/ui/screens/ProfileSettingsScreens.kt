package com.react.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.react.app.domain.Achievement
import com.react.app.domain.GameType
import com.react.app.domain.LevelSystem
import com.react.app.domain.Profile
import com.react.app.domain.RankLevel
import com.react.app.ui.components.AvatarImage
import com.react.app.ui.components.ConfirmDialog
import com.react.app.ui.components.NeonButton
import com.react.app.ui.components.NeonCard
import com.react.app.ui.components.NeonProgressBar
import com.react.app.ui.components.ScreenScaffold
import com.react.app.ui.components.SectionTitle
import com.react.app.ui.components.StatTile
import com.react.app.ui.fa
import com.react.app.ui.msText
import com.react.app.ui.percentText
import com.react.app.ui.theme.ReactColors
import com.react.app.ui.viewmodel.ProfileViewModel
import com.react.app.ui.viewmodel.SettingsViewModel
import com.react.app.util.PersianFormat

@Composable
fun ProfileScreen(vm: ProfileViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val profile = state.profile

    var name by remember { mutableStateOf(profile.name) }
    var avatar by remember { mutableIntStateOf(profile.avatar) }
    // بعد از بارگذاری از Room مقدار ذخیره‌شده یک‌بار در فرم قرار می‌گیرد.
    LaunchedEffect(profile.name, profile.avatar) {
        name = profile.name
        avatar = profile.avatar
    }
    val dirty = Profile.sanitizeName(name) != profile.name || avatar != profile.avatar

    ScreenScaffold("پروفایل", onBack) {
        Spacer(Modifier.height(8.dp))
        NeonCard(Modifier.fillMaxWidth(), accent = ReactColors.Green) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AvatarImage(avatar, avatarSize = 64.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(profile.name, color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleLarge)
                    Text("سطح ${profile.level.title}", color = ReactColors.Green, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(12.dp))
            NeonProgressBar(LevelSystem.progress(profile.xp))
            Spacer(Modifier.height(6.dp))
            val toNext = LevelSystem.xpToNext(profile.xp)
            Text(
                if (toNext > 0) "${profile.xp.fa()} XP · ${toNext.fa()} XP تا سطح ${LevelSystem.next(profile.level)?.title}" else "${profile.xp.fa()} XP · بالاترین سطح",
                color = ReactColors.TextSecondary,
                style = MaterialTheme.typography.bodySmall,
            )
        }

        SectionTitle("نام")
        BasicTextField(
            value = name,
            onValueChange = { name = it.take(Profile.MAX_NAME_LENGTH) },
            singleLine = true,
            textStyle = TextStyle(color = ReactColors.TextPrimary, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
            cursorBrush = SolidColor(ReactColors.Green),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            decorationBox = { inner ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(ReactColors.Card)
                        .border(1.dp, ReactColors.Outline, RoundedCornerShape(14.dp))
                        .padding(16.dp),
                ) { inner() }
            },
        )

        SectionTitle("آواتار")
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            (0 until Profile.AVATAR_COUNT).chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { i ->
                        Box(
                            Modifier
                                .clip(CircleShape)
                                .border(if (i == avatar) 3.dp else 0.dp, ReactColors.Green, CircleShape)
                                .padding(3.dp)
                                .clickable { avatar = i },
                        ) { AvatarImage(i, avatarSize = 60.dp) }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        NeonButton("ذخیره تغییرات", onClick = { vm.save(name, avatar) }, enabled = dirty)

        SectionTitle("آمار شخصی")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("کل آزمون‌ها", profile.totalTests.fa(), Modifier.weight(1f))
            StatTile("آزمون‌های موفق", profile.successfulTests.fa(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        val reaction = state.records.firstOrNull { it.gameType == GameType.REACTION }
        val memory = state.records.firstOrNull { it.gameType == GameType.MEMORY }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("بهترین واکنش", reaction?.bestSecondary?.takeIf { it > 0 }?.let { msText(it) } ?: "—", Modifier.weight(1f))
            StatTile("بهترین دقت", percentText(state.records.maxOfOrNull { it.bestAccuracy } ?: 0), Modifier.weight(1f), ReactColors.AccentAim)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("بهترین مرحله حافظه", (memory?.bestMain ?: 0).fa(), Modifier.weight(1f), ReactColors.AccentMemory)
            StatTile("موفقیت پیاپی فعلی", profile.successStreak.fa(), Modifier.weight(1f), ReactColors.AccentFocus)
        }

        SectionTitle("سطح‌ها")
        NeonCard(Modifier.fillMaxWidth()) {
            RankLevel.entries.forEachIndexed { i, level ->
                if (i > 0) Spacer(Modifier.height(8.dp))
                val reached = profile.xp >= level.minXp
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(level.title, color = if (reached) ReactColors.Green else ReactColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    Text("${level.minXp.fa()} XP", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        SectionTitle("دستاوردها (${state.unlocked.size.fa()} از ${Achievement.entries.size.fa()})")
        Achievement.entries.forEach { a ->
            val unlockedAt = state.unlocked[a]
            NeonCard(Modifier.fillMaxWidth(), accent = if (unlockedAt != null) ReactColors.AccentFocus else null, contentPadding = 14.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.title, color = if (unlockedAt != null) ReactColors.TextPrimary else ReactColors.TextSecondary, style = MaterialTheme.typography.titleMedium)
                        Text(a.description, color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        if (unlockedAt != null) PersianFormat.date(unlockedAt) else "قفل",
                        color = if (unlockedAt != null) ReactColors.AccentFocus else ReactColors.TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val settings by vm.settings.collectAsState()
    var showGuide by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmReset1 by remember { mutableStateOf(false) }
    var confirmReset2 by remember { mutableStateOf(false) }

    ScreenScaffold("تنظیمات", onBack) {
        Spacer(Modifier.height(8.dp))
        NeonCard(Modifier.fillMaxWidth()) {
            SettingSwitch("صدا", "افکت‌های صوتی بازی", settings.soundEnabled, vm::setSound)
            Spacer(Modifier.height(8.dp))
            SettingSwitch("لرزش", "بازخورد لرزشی هنگام لمس و خطا", settings.vibrationEnabled, vm::setVibration)
        }
        Spacer(Modifier.height(12.dp))
        NeonCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("زبان", color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Text("فارسی (فعال)", color = ReactColors.Green, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(4.dp))
            Text("زبان‌های دیگر در نسخه‌های بعدی اضافه می‌شوند.", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(12.dp))
        NeonCard(Modifier.fillMaxWidth(), onClick = { showGuide = true }) {
            Text("راهنمای بازی", color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(12.dp))
        NeonCard(Modifier.fillMaxWidth(), onClick = { showAbout = true }) {
            Text("درباره REACT", color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
        }

        SectionTitle("داده‌ها")
        NeonCard(Modifier.fillMaxWidth(), onClick = { confirmClear = true }) {
            Text("پاک کردن تاریخچه", color = ReactColors.Warning, style = MaterialTheme.typography.titleMedium)
            Text("فقط فهرست آزمون‌ها پاک می‌شود؛ رکوردها، XP، سطح و دستاوردها می‌مانند.", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(12.dp))
        NeonCard(Modifier.fillMaxWidth(), onClick = { confirmReset1 = true }) {
            Text("بازنشانی کامل اطلاعات", color = ReactColors.Warning, style = MaterialTheme.typography.titleMedium)
            Text("همه چیز (تاریخچه، رکوردها، XP، دستاوردها، پروفایل و تنظیمات) پاک می‌شود.", color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showGuide) InfoDialog("راهنمای بازی", GuideText) { showGuide = false }
    if (showAbout) InfoDialog("درباره REACT", AboutText) { showAbout = false }
    if (confirmClear) {
        ConfirmDialog(
            "پاک کردن تاریخچه؟", "تاریخچه همه آزمون‌ها حذف می‌شود. این کار قابل بازگشت نیست.", "پاک کن",
            onConfirm = { vm.clearHistory(); confirmClear = false },
            onDismiss = { confirmClear = false },
        )
    }
    if (confirmReset1) {
        ConfirmDialog(
            "بازنشانی کامل؟", "تمام اطلاعات این برنامه از روی گوشی پاک می‌شود.", "ادامه",
            onConfirm = { confirmReset1 = false; confirmReset2 = true },
            onDismiss = { confirmReset1 = false },
        )
    }
    if (confirmReset2) {
        ConfirmDialog(
            "تأیید نهایی", "آیا مطمئنی؟ همه رکوردها، XP، سطح و دستاوردها برای همیشه حذف می‌شوند.", "بله، همه را پاک کن",
            onConfirm = { vm.resetAll(); confirmReset2 = false },
            onDismiss = { confirmReset2 = false },
        )
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = ReactColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = ReactColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ReactColors.Background,
                checkedTrackColor = ReactColors.Green,
                uncheckedThumbColor = ReactColors.TextSecondary,
                uncheckedTrackColor = ReactColors.CardHigh,
            ),
        )
    }
}

@Composable
private fun InfoDialog(title: String, text: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ReactColors.Card,
        titleContentColor = ReactColors.TextPrimary,
        textContentColor = ReactColors.TextSecondary,
        title = { Text(title) },
        text = {
            Column(Modifier.padding(0.dp)) {
                Text(text, style = MaterialTheme.typography.bodyMedium)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن", color = ReactColors.Green) } },
    )
}

private const val GuideText = """تست سرعت واکنش: صفحه قرمز است؛ وقتی سبز شد سریع لمس کن. لمس زودهنگام خطا حساب می‌شود. پنج دور دارد.

تست حافظه: ترتیب خانه‌های روشن‌شده را تکرار کن. هر مرحله یک حرکت بیشتر می‌شود.

تست تمرکز: شکل هدف را میان شکل‌های مشابه پیدا کن؛ پاسخ اشتباه امتیاز منفی دارد.

تست دقت: اهداف متحرک را قبل از ناپدید شدن لمس کن؛ لمس خالی جریمه دارد.

چالش رنگ‌ها: رنگ واقعی نوشته را انتخاب کن، نه معنی کلمه را.

با هر آزمون XP می‌گیری و سطحت بالا می‌رود."""

private const val AboutText = """REACT — سرعتت رو ثابت کن.

اپلیکیشن سرگرمی و آزمون مهارت‌های واکنش، حافظه، تمرکز و دقت.

نسخه ۱.۰.۰
کاملاً آفلاین: بدون ثبت‌نام، بدون تبلیغ و بدون ارسال هیچ اطلاعاتی؛ همه‌چیز فقط روی گوشی خودت ذخیره می‌شود."""
