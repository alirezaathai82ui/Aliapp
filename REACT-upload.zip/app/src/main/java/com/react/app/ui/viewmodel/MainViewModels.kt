package com.react.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.react.app.AppContainer
import com.react.app.data.prefs.AppSettings
import com.react.app.domain.Achievement
import com.react.app.domain.GameType
import com.react.app.domain.Profile
import com.react.app.domain.RecordSnapshot
import com.react.app.domain.ResultRecord
import com.react.app.domain.StatsCalculator
import com.react.app.domain.StatsSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReactViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        HomeViewModel::class.java -> HomeViewModel(container)
        StatsViewModel::class.java -> StatsViewModel(container)
        ProfileViewModel::class.java -> ProfileViewModel(container)
        SettingsViewModel::class.java -> SettingsViewModel(container)
        ReactionViewModel::class.java -> ReactionViewModel(container)
        MemoryViewModel::class.java -> MemoryViewModel(container)
        FocusViewModel::class.java -> FocusViewModel(container)
        AimViewModel::class.java -> AimViewModel(container)
        StroopViewModel::class.java -> StroopViewModel(container)
        else -> throw IllegalArgumentException("ViewModel ناشناخته: ${modelClass.name}")
    } as T
}

data class HomeState(
    val loaded: Boolean = false,
    val profile: Profile = Profile(),
    val summary: StatsSummary = StatsCalculator.summarize(emptyList()),
    val recent: List<ResultRecord> = emptyList(),
)

class HomeViewModel(container: AppContainer) : ViewModel() {
    val state: StateFlow<HomeState> = combine(
        container.repository.profile,
        container.repository.results,
        container.repository.records,
    ) { profile, results, records ->
        HomeState(
            loaded = true,
            profile = profile,
            summary = StatsCalculator.summarize(results, records, profile.totalTests, profile.successfulTests),
            recent = results.take(4),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())
}

data class StatsState(
    val loaded: Boolean = false,
    val filter: GameType? = null,
    val summary: StatsSummary = StatsCalculator.summarize(emptyList()),
    val trend: List<Int> = emptyList(),
    val history: List<ResultRecord> = emptyList(),
)

class StatsViewModel(container: AppContainer) : ViewModel() {
    private val filter = MutableStateFlow<GameType?>(null)

    val state: StateFlow<StatsState> = combine(
        container.repository.profile,
        container.repository.results,
        container.repository.records,
        filter,
    ) { profile, results, records, selected ->
        StatsState(
            loaded = true,
            filter = selected,
            summary = StatsCalculator.summarize(results, records, profile.totalTests, profile.successfulTests),
            trend = StatsCalculator.trend(results, selected),
            history = results.filter { selected == null || it.gameType == selected },
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsState())

    fun setFilter(type: GameType?) {
        filter.value = type
    }
}

data class ProfileState(
    val profile: Profile = Profile(),
    val records: List<RecordSnapshot> = emptyList(),
    val unlocked: Map<Achievement, Long> = emptyMap(),
)

class ProfileViewModel(private val container: AppContainer) : ViewModel() {
    val state: StateFlow<ProfileState> = combine(
        container.repository.profile,
        container.repository.records,
        container.repository.achievements,
    ) { profile, records, unlocked -> ProfileState(profile, records, unlocked) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProfileState())

    fun save(name: String, avatar: Int) {
        viewModelScope.launch { container.repository.updateProfile(name, avatar) }
    }
}

class SettingsViewModel(private val container: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = container.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    fun setSound(enabled: Boolean) {
        viewModelScope.launch { container.settings.setSoundEnabled(enabled) }
    }

    fun setVibration(enabled: Boolean) {
        viewModelScope.launch { container.settings.setVibrationEnabled(enabled) }
    }

    fun clearHistory() {
        viewModelScope.launch { container.repository.clearHistory() }
    }

    fun resetAll() {
        viewModelScope.launch { container.repository.resetAll() }
    }
}
