# مستندات فنی

## پشته
Kotlin 2.0.21، Jetpack Compose (BOM 2024.12.01)، Material 3، Navigation Compose 2.8.5، Room 2.6.1 (KSP)، DataStore Preferences 1.1.1، Coroutines/StateFlow، minSdk 26، targetSdk 35، applicationId `com.react.app`.

## معماری
MVVM لایه‌ای:
- `domain/`: منطق خالص بدون وابستگی به Android (قابل تست روی JVM). زمان همیشه از بیرون تزریق می‌شود.
- `data/db`: Room. `data/prefs`: DataStore. `data/repo/ReactRepository`: تنها نقطه نوشتن (تراکنش).
- `feedback/`: صدا (AudioTrack از PCM سنتزشده) و لرزش.
- `ui/`: تم، کامپوننت‌ها، ناوبری، صفحات، ViewModelها.
- DI دستی: `AppContainer` در `ReactApp.kt`.

## دیتابیس (Room v1، فایل `react.db`)
- `test_results`: تاریخچه (id, gameType, score, performance, success, accuracy(-1=نامربوط), mainValue, bestValue, xpGained, createdAt). فقط ۵۰۰ مورد آخر خوانده می‌شود.
- `records`: بهترین‌های هر بازی (با پاک کردن تاریخچه حفظ می‌شود).
- `achievements`: (id=نام enum، unlockedAt).
- `profile`: یک ردیف id=1 (name, avatar, xp, level, totalTests, successfulTests, successStreak).
معنی `mainValue/bestValue`: واکنش = میانگین/بهترین دور (ms)؛ حافظه = مراحل کامل؛ بقیه = امتیاز و میانگین زمان پاسخ درست.

## قوانین امتیازدهی
- عملکرد ۰..۱۰۰؛ موفق اگر ≥ ۵۰.
- XP هر آزمون = ۱۰ + عملکرد/۵ + (۱۰ اگر موفق) → حداکثر ۴۰.
- سطوح XP: ۰ تازه‌کار، ۱۵۰ مبتدی، ۴۵۰ متوسط، ۱۰۰۰ حرفه‌ای، ۲۰۰۰ استاد، ۳۵۰۰ نخبه.
- امتیاز کلی: میانگین «میانگین عملکرد ۵ آزمون اخیر هر بازی» روی بازی‌های انجام‌شده.
- واکنش: عملکرد = (۷۰۰ − میانگین)·۱۰۰/۵۰۰ − ۵ برای هر خطای شروع زودهنگام؛ زمان‌های <۸۰ms خطای پیش‌بینی؛ مهلت ۲۰۰۰ms.

## DataStore
`react_settings`: sound_enabled, vibration_enabled, language (فعلاً فقط fa).

## آفلاین
Manifest فقط `VIBRATE` دارد. هیچ کتابخانه شبکه‌ای در وابستگی‌ها نیست. صدا در زمان اجرا سنتز می‌شود (بدون فایل/مجوز).

## اجرای تست‌های domain بدون Android SDK
`tools/verify-domain.sh` (نیاز: JDK + Gradle نصب‌شده در `/opt/gradle-8.14.3/lib`، یا `GRADLE_LIB=...`).
