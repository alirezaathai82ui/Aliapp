# وضعیت پروژه REACT

آخرین به‌روزرسانی: 2026-11-20 (پایان جلسه ۲)

## پیشرفت تقریبی: ~75٪ از «کد نوشته‌شده» — ولی **۰٪ از «بیلد تأییدشده»**

## محدودیت محیط (مهم)
در محیط ابری Android SDK نصب نبود و شبکه برای دانلود بسته‌ها بسته بود.
- **Gradle/AGP/Compose/Room هرگز اجرا نشده‌اند. APK ساخته نشده و روی دستگاه/شبیه‌ساز تست نشده است.**
- فقط `domain/` و `util/` با کامپایلر Kotlin 2.0.21 داخل Gradle روی JVM کامپایل و تست شده‌اند (۷۲ تست سبز).
- تمام فایل‌های دیگر (۲۰ فایل Kotlin: UI، Room، DataStore، Feedback) فقط نوشته شده‌اند و **ممکن است خطای کامپایل داشته باشند**.

## کامل و تأییدشده (کامپایل + تست JVM)
منطق پنج بازی، امتیاز/XP/سطح، آمار، دستاوردها، رکوردها، تاریخ شمسی، سنتز صدا.

## نوشته‌شده ولی کامپایل‌نشده
- Room (`data/db`)، DataStore، Repository (ثبت اتمیک نتیجه)، Feedback (صدا/لرزش)
- ViewModelها: `ui/viewmodel/MainViewModels.kt`, `GameViewModels.kt`
- کامپوننت‌ها: `ui/components/Common.kt`, `Icons.kt`
- صفحات: Splash، Home، Stats، Profile، Settings، پنج بازی (+ معرفی/نتیجه مشترک `GameCommon.kt`)
- ناوبری: `ui/nav/ReactNavHost.kt`
- Gradle، Manifest (فقط VIBRATE)، منابع، آیکن لانچر، README

## باقی‌مانده
- **ساخت واقعی با Android SDK و رفع خطاهای کامپایل** (مهم‌ترین)
- فونت Vazirmatn، تست روی دستگاه، تست Repository/Room، بررسی Manifest ادغام‌شده، آزمایش Airplane Mode
- جزئیات: `TASKS.md`
