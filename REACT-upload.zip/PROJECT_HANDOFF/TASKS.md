# کارها

## انجام‌شده (کد نوشته شد؛ ✔ = علاوه بر آن کامپایل/تست JVM شد)
- [x] بررسی محیط (JDK 21، Gradle 8.14.3؛ بدون Android SDK و شبکه)
- [x] ساختار Gradle، Manifest بدون INTERNET، آیکن لانچر، تم
- [x] ✔ منطق پنج بازی + سطح‌بندی/XP + دستاوردها + آمار + رکوردها (۷۲ تست)
- [x] Room + DataStore + Repository
- [x] صدا (سنتز در زمان اجرا) و لرزش
- [x] تم، لوگو، آیکن بازی‌ها، آواتارها، کامپوننت‌های مشترک
- [x] ViewModelها و ناوبری
- [x] صفحات: Splash، Home، Stats، Profile، Settings، پنج بازی
- [x] README و مستندات Handoff

## باقی‌مانده (به ترتیب اولویت)
1. **با Android SDK:** `./gradlew testDebugUnitTest assembleDebug` و رفع همه خطاهای کامپایل (هرگز اجرا نشده!)
2. تأیید نسخه‌های `gradle/libs.versions.toml` (AGP 8.7.3، KSP 2.0.21-1.0.28، Compose BOM 2024.12.01) با Sync واقعی
3. اجرا روی شبیه‌ساز/گوشی: بررسی هر ۵ بازی، ناوبری، ذخیره و بازیابی بعد از بستن کامل برنامه، چرخش/تغییر پیکربندی
4. بررسی Manifest ادغام‌شده (نبودن INTERNET) و آزمایش Airplane Mode
5. افزودن فونت Vazirmatn در `res/font/`
6. تست‌های Repository/Room (androidTest یا Robolectric) و تست ViewModelها
7. بهبود UI: انیمیشن‌های ظریف‌تر، بازبینی روی نمایشگرهای کوچک/بزرگ و fontScale بالا
8. پاک‌سازی importهای بلااستفاده (`ReactionMemoryScreens.kt` و غیره) و اجرای lint
