# وضعیت فعلی

## آخرین کار
نوشتن کامل لایه UI: Common.kt، ViewModelها، GameCommon، شش فایل صفحه، ReactNavHost؛ سپس README و به‌روزرسانی Handoff.

## آخرین Build/تست
- JVM: `tools/verify-domain.sh` → **OK (72 tests)** روی domain+util (آخرین اجرا بعد از نوشتن UI؛ UI در آن شرکت ندارد).
- Gradle/Android build: **هرگز اجرا نشده** (SDK نبود). ~۲۰ فایل Kotlin کامپایل‌نشده است.

## فایل‌های مهم (همه زیر `app/src/main/java/com/react/app/`)
`ui/viewmodel/{MainViewModels,GameViewModels}.kt`, `ui/components/{Common,Icons}.kt`,
`ui/screens/{GameCommon,ReactionMemoryScreens,FocusAimStroopScreens,HomeStatsScreens,ProfileSettingsScreens}.kt`,
`ui/nav/ReactNavHost.kt`, `ui/theme/Theme.kt`, `ui/Format.kt`, `feedback/Feedback.kt`, `data/**`, `ReactApp.kt`, `MainActivity.kt`.

## حدس‌های پرریسک برای خطای کامپایل (چون هرگز کامپایل نشده)
- `Icons.kt`: `PathMeasure`/`getSegment`، `drawPath(style=)`
- `Common.kt`: `LocalLifecycleOwner` از `androidx.compose.ui.platform` (در نسخه‌های جدیدتر منتقل/منسوخ شده)، `Modifier.shadow(ambientColor, spotColor)`
- `Theme.kt`: `getIdentifier` برای فونت اختیاری
- `ReactRepository.kt`: `db.withTransaction` (نیاز به `room-ktx`، موجود است)
- `FocusAimStroopScreens.kt`: `return@ScreenScaffold` داخل `when`، ایمپورت‌های کامل
- `AimScreen`: اندازه محیط = ارتفاع BoxWithConstraints − ۷۲dp (ارتفاع HUD ثابت)
- importهای بلااستفاده در چند فایل (فقط warning)

## مشکلات/نکات طراحی
- جهت صفحه در Manifest روی portrait قفل است؛ ViewModelها حالت بازی را در تغییر پیکربندی نگه می‌دارند و با ON_STOP بازی بدون ثبت نتیجه لغو می‌شود.
- ثبت نتیجه در `NonCancellable` + تراکنش Room؛ پاک کردن تاریخچه رکوردها/XP/دستاوردها را حفظ می‌کند.
- آواتار ۸ طرح داخلی (Canvas)؛ فونت اختیاری Vazirmatn داخل پروژه نیست.

## مرحله بعد دقیقاً
در محیطی با Android SDK: `./gradlew assembleDebug`، خطاها را یکی‌یکی رفع کن، سپس تست روی دستگاه.
