# پرامپت جلسه بعد (کپی کنید)

تو Senior Android Developer هستی و توسعه‌ی اپ اندرویدی **REACT** را ادامه می‌دهی (فارسی، RTL، مشکی/سبز نئونی، ۱۰۰٪ آفلاین، Kotlin + Compose + Material3 + MVVM + Room + DataStore). پروژه در پوشه‌ی `REACT/` است.

۱) ابتدا `PROJECT_HANDOFF/PROJECT_STATUS.md`, `TECHNICAL_DOCUMENTATION.md`, `TASKS.md`, `CURRENT_STATE.md` را بخوان، سپس وضعیت واقعی کد را با آن‌ها مقایسه کن.
۲) محیط را بررسی کن (`java -version`, `echo $ANDROID_HOME`, `gradle --version`). اگر Android SDK هست: `./gradlew testDebugUnitTest assembleDebug` را اجرا کن و **اول خطاهای کامپایل کد نوشته‌شده‌ی قبلی** (Room/Compose/Feedback/Icons/Theme) را رفع کن؛ تاکنون هرگز کامپایل نشده‌اند. اگر SDK نیست، فقط `tools/verify-domain.sh` را می‌توانی اجرا کنی؛ هرگز ادعای ساخت APK نکن.
۳) کار را از «مرحله بعد» در `CURRENT_STATE.md` ادامه بده: کامپوننت‌های مشترک → ViewModelها → NavHost → Splash/Home → پنج بازی → آمار → پروفایل → تنظیمات.
۴) قوانین: مجوز INTERNET ممنوع؛ هیچ دکمه/نمودار نمایشی؛ همه‌چیز از Room/DataStore؛ ثبت نتیجه فقط با `ReactRepository.recordResult`؛ زمان واکنش با `SystemClock.elapsedRealtimeNanos` و منطق در `ReactSession`؛ متن‌ها فارسی با ارقام فارسی (`fa()`).
۵) پایان هر مرحله PROJECT_HANDOFF را به‌روز کن (کارهای نیمه‌تمام را تمام‌شده اعلام نکن). منتظر تأیید من نمان.
