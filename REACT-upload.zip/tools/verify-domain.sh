#!/usr/bin/env bash
# کامپایل و اجرای تست‌های منطق خالص (بدون Android SDK) با کامپایلر Kotlin که داخل Gradle هست.
# فقط پکیج‌های domain و util را می‌سازد؛ کد Android/Compose/Room را کامپایل نمی‌کند.
# استفاده:  GRADLE_LIB=/opt/gradle-8.14.3/lib tools/verify-domain.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LIB="${GRADLE_LIB:-/opt/gradle-8.14.3/lib}"
OUT="${OUT_DIR:-$(mktemp -d)}"

KOTLINC_CP="$LIB/kotlin-compiler-embeddable-2.0.21.jar:$LIB/kotlin-stdlib-2.0.21.jar:$LIB/kotlin-script-runtime-2.0.21.jar:$LIB/kotlin-reflect-2.0.21.jar:$LIB/kotlin-daemon-embeddable-2.0.21.jar:$LIB/trove4j-1.0.20200330.jar:$LIB/kotlinx-coroutines-core-jvm-1.6.4.jar:$LIB/annotations-24.0.1.jar"
RUN_CP="$LIB/kotlin-stdlib-2.0.21.jar:$LIB/junit-4.13.2.jar:$LIB/hamcrest-core-1.3.jar"

MAIN_SRC="$ROOT/app/src/main/java/com/react/app"
TEST_SRC="$ROOT/app/src/test/java/com/react/app"

java -cp "$KOTLINC_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
  -no-stdlib -no-reflect -cp "$RUN_CP" -d "$OUT" \
  "$MAIN_SRC/domain" "$MAIN_SRC/util" "$TEST_SRC/domain" "$TEST_SRC/util"

CLASSES=$(cd "$OUT" && find com -name '*Test.class' | sed 's/\.class$//; s#/#.#g' | sort | tr '\n' ' ')
echo "Running: $CLASSES"
java -cp "$OUT:$RUN_CP" org.junit.runner.JUnitCore $CLASSES
